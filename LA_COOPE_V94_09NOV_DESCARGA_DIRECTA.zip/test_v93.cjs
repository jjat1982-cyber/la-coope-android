'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const reader=fs.readFileSync('app/src/main/assets/fcf-reader.js','utf8');
const driver=fs.readFileSync('app/src/main/assets/fcf-auto.js','utf8');
function parse(text,url='https://www.fcf.cat/ca/competicio'){
 const document={body:{innerText:text},querySelectorAll:()=>[]};
 return JSON.parse(vm.runInNewContext(reader,{document,location:new URL(url),URL,Date,console},{timeout:800}));
}
const adult=`SELECTOR DE COMPETICIÓ
2026-27
Futbol 11
PRIMERA CATALANA
GRUP 3
RESULTATS
CLASSIFICACIÓ
CALENDARI
JORNADA 8
SANTBOIA, F.C. A
ACTA TANCADA
07/11/2026
16:00
4 - 0
VILA-SECA C.F. A
INFORMACIÓ DEL CAMP
JORNADA 8
CIUDAD COOPERATIVA, C.F. A
ACTA TANCADA
08/11/2026
12:00
2 - 1
SITGES, U.E. A
INFORMACIÓ DEL CAMP`;
let p=parse(adult);
assert.equal(p.group,'3');assert.match(p.category,/primera catalana/i);
assert(p.results.some(x=>x.home.toUpperCase().includes('CIUDAD COOPERATIVA')&&x.score==='2-1'),'Expected closed FCF card result with club');
assert(!p.results.some(x=>x.score==='4-0'),'Must not insert other clubs match');
assert.equal(parse('Internal Server Error').results.length,0);
console.log('PASS: lectura de tarjetas oficiales simuladas, exclusión de otros clubes y contexto de grupo');
