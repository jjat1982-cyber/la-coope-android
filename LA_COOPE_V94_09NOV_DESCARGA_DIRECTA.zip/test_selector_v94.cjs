const fs=require('fs'),vm=require('vm'),assert=require('assert');
const code=fs.readFileSync('app/src/main/assets/fcf-auto.js','utf8');
function execute(ctx){return JSON.parse(vm.runInNewContext(code,ctx))}
function mockSelect(label,optionNames){
 const x={tagName:'SELECT',name:label,id:label,options:optionNames.map(s=>({textContent:s,value:s})),value:'',selectedOptions:[],
   getAttribute:()=>null,getBoundingClientRect:()=>({width:180,height:42})};
 x.selectedOptions=[{textContent:'Seleccionar'}];return x;
}
const sel=[mockSelect('Temporada',['2026-27']),mockSelect('Disciplina',['Futbol 11']),mockSelect('Competicion',['PRIMERA CATALANA']),mockSelect('Grupo',['GRUP 3'])];
class HTMLSelectElement{}
Object.defineProperty(HTMLSelectElement.prototype,'value',{set(v){this._value=v;this.selectedOptions=[this.options.find(o=>o.value===v)]},get(){return this._value}});
sel.forEach(s=>{Object.setPrototypeOf(s,HTMLSelectElement.prototype);s.dispatchEvent=()=>{}});
const c={window:{__COOPE_TARGET__:{division:'Primera Catalana',group:'3',discipline:'futbol 11'},getComputedStyle:()=>({display:'block',visibility:'visible'})},location:{hostname:'www.fcf.cat',protocol:'https:'},
 document:{querySelectorAll:()=>sel,getElementById:()=>null},HTMLSelectElement,Event:class{},Node:{DOCUMENT_POSITION_FOLLOWING:4}};
for(let i=0;i<4;i++){const r=execute(c);assert.equal(r.state,'working');assert.equal(r.step,i);}
assert.equal(execute(c).state,'ready');console.log('PASS: selección nativa 4 campos y grupo');
const triggers=['Temporada','Disciplina','Competición','Grupo'].map((label,i)=>({tagName:'BUTTON',id:'',name:'',textContent:'Seleccionar',innerText:'Seleccionar',label,show:false,
  getAttribute(n){return n==='aria-label'?label:null},getBoundingClientRect:()=>({width:190,height:44}),click(){this.show=true},dispatchEvent:()=>{},compareDocumentPosition:()=>4}));
const vals=['2026-27','Futbol 11','PRIMERA CATALANA','GRUP 3'];
const ctxt={window:{__COOPE_TARGET__:{division:'Primera Catalana',group:'3',discipline:'futbol 11'},getComputedStyle:()=>({display:'block',visibility:'visible'})},location:c.location,
 document:{querySelectorAll(selector){
  if(selector.includes('[role="option"]')){
   const active=triggers.findIndex(t=>t.show);if(active<0)return[];
   return [{tagName:'LI',textContent:vals[active],innerText:vals[active],getBoundingClientRect:()=>({width:180,height:20}),click(){triggers[active].innerText=vals[active];triggers[active].textContent=vals[active];triggers[active].show=false}}];
  }if(selector.includes('select,[role="combobox"]'))return triggers;return[]},getElementById:()=>null},HTMLSelectElement,Event:class{},Node:c.Node};
for(let i=0;i<4;i++){const x=execute(ctxt);assert.equal(x.state,'working');assert.equal(x.step,i);const y=execute(ctxt);assert.equal(y.state,'working');assert.equal(y.step,i)}
assert.equal(execute(ctxt).state,'ready');console.log('PASS: selectores personalizados con opciones verificadas');
const empty={...ctxt,window:{...ctxt.window,__LA_COOPE_DROPDOWN__:null},document:{querySelectorAll(){return[]},getElementById:()=>null}};
let z;for(let i=0;i<5;i++)z=execute(empty);
assert.equal(z.state,'blocked');assert.equal(z.step,0);console.log('PASS: ausencia de selector produce diagnóstico, sin clics aleatorios');
