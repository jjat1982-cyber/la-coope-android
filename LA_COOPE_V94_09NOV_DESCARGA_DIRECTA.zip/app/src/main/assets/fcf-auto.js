/* LA COOPE 9.4: selector conservador para formularios públicos de competiciones FCF.
   No consulta APIs privadas, no salta autenticación ni protección de acceso.
   Solo confirma READY después de leer cuatro valores seleccionados inequívocos.
*/
(function(){
  try {
    if(location.protocol!=='https:' || !['fcf.cat','www.fcf.cat'].includes(location.hostname)){
      return JSON.stringify({state:'error',reason:'La web no pertenece a la FCF'});
    }
    const t=window.__COOPE_TARGET__||{};
    const digits=String(t.group||'').replace(/\D/g,'');
    if(!t.division||!digits) return JSON.stringify({state:'error',reason:'Falta categoría o grupo en LA COOPE'});
    const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    const fieldNames=['temporada','disciplina','competicion','grupo'];
    const titleNames=['Temporada','Disciplina','Competición','Grupo'];
    const fieldRx=[/^(temporada|season)$/,/^(disciplina|modalitat|modalidad|disciplina esportiva)$/,/^(competicio|competicion|categoria|category)$/,/^(grup|grupo|group)$/];
    const fieldHints=[/\btemporada\b|\bseason\b/,/\bdisciplina\b|\bmodalitat\b|\bmodalidad\b/,/\bcompeticio\b|\bcompeticion\b|\bcategoria\b|\bcategory\b/,/\bgrup\b|\bgrupo\b|\bgroup\b/];
    const division=norm(t.division).replace(/\bdivisio\b|\bdivision\b/g,'').replace(/\s+/g,' ').trim();
    const candidates=[['2026 27'],[norm(t.discipline||'futbol 11')],[division],[`grup ${digits}`,`grupo ${digits}`]];
    const cleanLevel=s=>norm(s).replace(/\bdivisio\b|\bdivision\b|\bdivision de\b/g,'').replace(/\bfemenino\b/g,'femeni').replace(/\bcadete\b/g,'cadet').replace(/\balevin\b/g,'alevi').replace(/\bbenjamin\b/g,'benjami').replace(/\bprebenjamin\b/g,'prebenjami');
    const matches=(v,i)=>{
      const a=norm(v);if(!a)return false;
      if(i===0)return a==='2026 27' || a==='2026 2027';
      if(i===1)return a===candidates[i][0] || a.replace('futbol','futbol')===candidates[i][0];
      if(i===2){const b=cleanLevel(candidates[i][0]),x=cleanLevel(a);
        // Only match the exact official division; do not confuse S14 with S13 or Primera with Segona.
        return !!b && (x===b || x===`${b} futbol 11` || x===`futbol 11 ${b}`);
      }
      if(i===3)return a===`grup ${digits}`||a===`grupo ${digits}`||a===digits;
      return false;
    };
    const isVisible=el=>{
      if(!el || !el.getBoundingClientRect)return false;
      const r=el.getBoundingClientRect();
      const cs=window.getComputedStyle?.(el);
      return r.width>0&&r.height>0&&cs?.display!=='none'&&cs?.visibility!=='hidden';
    };
    const short=el=>String(el?.innerText||el?.textContent||'').replace(/\s+/g,' ').trim().slice(0,120);
    const controls=[...document.querySelectorAll('select,[role="combobox"],input[aria-haspopup],button[aria-haspopup],button[aria-expanded],button[data-bs-toggle="dropdown"],.select2-selection,.ng-select-container,.choices__inner,.ts-control,.vs__dropdown-toggle,.multiselect__select,.multiselect__tags,.dropdown-toggle,[class*="select__control"],[class*="custom-select"],[class*="select-trigger"],[class*="selector__control"],.form-select,div[aria-haspopup]')]
      .filter(x=>isVisible(x)||x.tagName==='SELECT');
    const labels=[...document.querySelectorAll('label,span,p,strong,small,div')].filter(el=>{
      const own=norm(el.textContent);return own.length<30&&fieldRx.some(rx=>rx.test(own))&&(!el.children.length||[...el.children].every(x=>x.tagName==='I'||x.tagName==='SVG'));
    });
    const semantic=(el)=>norm([el?.id,el?.name,el?.getAttribute?.('aria-label'),el?.getAttribute?.('data-placeholder'),el?.getAttribute?.('placeholder'),el?.getAttribute?.('title')].filter(Boolean).join(' '));
    function fieldControl(i){
      // 1) Prefer explicit accessible labels or form names.
      for(const el of controls){if(fieldHints[i].test(semantic(el)))return el;}
      for(const label of labels){if(!fieldRx[i].test(norm(label.textContent)))continue;
        if(label.htmlFor){const linked=document.getElementById(label.htmlFor);if(linked)return linked;}
        let ancestor=label.parentElement;
        for(let depth=0;depth<4&&ancestor;depth++,ancestor=ancestor.parentElement){
          const found=controls.filter(el=>ancestor.contains(el)&&el!==label);
          if(found.length===1)return found[0];
          if(found.length>1){
            const below=found.filter(x=>label.compareDocumentPosition(x)&Node.DOCUMENT_POSITION_FOLLOWING);
            if(below.length===1)return below[0];
          }
        }
      }
      // 2) A control showing precisely the requested value can be verified without clicking.
      const equal=controls.filter(el=>matches(selectedText(el),i));
      if(equal.length===1)return equal[0];
      // 3) Native selects: identify the correct field by its option texts; don't use page order.
      const native=controls.filter(el=>el.tagName==='SELECT'&&[...el.options].some(o=>matches(o.textContent,i)));
      if(native.length===1)return native[0];
      return null;
    }
    function selectedText(el){
      if(!el)return '';
      if(el.tagName==='SELECT')return String(el.selectedOptions?.[0]?.textContent||'');
      if(el.tagName==='INPUT')return String(el.value||el.getAttribute('placeholder')||'');
      const s=short(el);return s.length<=95?s:'';
    }
    function chooseNative(el,i){
      const option=[...el.options].find(o=>matches(o.textContent,i));
      if(!option)return {state:'waiting',step:i,reason:'La FCF todavía no ofrece '+titleNames[i]};
      const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value')?.set;
      if(setter)setter.call(el,option.value);else el.value=option.value;
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
      return {state:'working',step:i,reason:'Seleccionando '+titleNames[i]+': '+option.textContent.trim()};
    }
    function findOpenOptions(){
      const opt=[...document.querySelectorAll('[role="option"],.select2-results__option,.ng-option,.choices__item--choice,.vs__dropdown-option,.multiselect__option,.dropdown-menu li,.dropdown-menu button,[role="listbox"] li,[role="listbox"] button,[role="listbox"] div')];
      return [...new Set(opt)].filter(x=>isVisible(x)&&short(x).length>0&&short(x).length<110);
    }
    const state=window.__LA_COOPE_DROPDOWN__||{step:-1,attempts:0,opened:false};
    const fields=fieldNames.map((n,i)=>({name:n,control:fieldControl(i)}));
    const selected=fields.map((f,i)=>matches(selectedText(f.control),i));
    // Each field must be independently identified and have the expected selected value.
    if(selected.every(Boolean)){
      window.__LA_COOPE_DROPDOWN__={step:-1,attempts:0,opened:false};
      return JSON.stringify({state:'ready',reason:'Temporada, modalidad, competición y grupo confirmados'});
    }
    const i=selected.findIndex(ok=>!ok);
    const f=fields[i];
    if(state.step!==i){state.step=i;state.attempts=0;state.opened=false;}
    state.attempts++;
    window.__LA_COOPE_DROPDOWN__=state;
    if(!f.control){
      const detail=`Controles ${controls.length}; etiquetas ${labels.length}; campos reconocidos ${fields.filter(x=>!!x.control).length}/4`;
      return JSON.stringify({state:state.attempts>=5?'blocked':'waiting',step:i,reason:'No se identifica el selector de '+titleNames[i]+'. '+detail});
    }
    if(f.control.tagName==='SELECT')return JSON.stringify(chooseNative(f.control,i));
    if(state.opened){
      const options=findOpenOptions();
      const choice=options.find(el=>matches(short(el),i));
      if(choice){choice.click();state.opened=false;state.attempts=0;
        return JSON.stringify({state:'working',step:i,reason:'Seleccionada opción de '+titleNames[i]});}
      if(state.attempts>=5)return JSON.stringify({state:'blocked',step:i,reason:'La FCF no muestra opciones reconocibles para '+titleNames[i]+' (visibles: '+options.length+').'});
      return JSON.stringify({state:'waiting',step:i,reason:'Esperando opciones de '+titleNames[i]+' ('+options.length+' visibles)'});
    }
    // Never click an arbitrary button by index. Only click a control matched to the expected field.
    f.control.click();state.opened=true;
    return JSON.stringify({state:'working',step:i,reason:'Abriendo '+titleNames[i]+' verificado'});
  } catch(e){return JSON.stringify({state:'error',reason:'Selector FCF: '+String(e.message||e).slice(0,145)});}
})()
