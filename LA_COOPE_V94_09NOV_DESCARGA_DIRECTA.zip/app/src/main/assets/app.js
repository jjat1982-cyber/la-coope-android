'use strict';
const CLUB='https://www.fcf.cat/ca/clubs';
const ACT_EXAMPLE='https://www.fcf.cat/ca/competicio/acta/4208561';
const COMP='https://www.fcf.cat/ca/competicio';
const COMP_LIST='https://www.fcf.cat/ca/competicio-futbol';
const KEY_FAV='lacoope-v8-favorite';
const KEY_VIEW='lacoope-v8-selected';
const MAIN_TEAM='amateur-a';
const DATA_KEY='lacoope-v93-fcf-snapshot';
const OLD_DATA_KEY='lacoope-v92-fcf-snapshot';
let officialSnapshots={};let sourceStatus='Preparando actualización automática…';
let teams=[],knownGames=[];
let tab='inicio', selected=MAIN_TEAM, favorite='',category='Todos', search='',filterGames='todos';
let installPrompt=null,toastTimer=null;
const safe=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const byId=id=>teams.find(t=>t.id===id)||teams[0];
const save=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const load=k=>{try{return localStorage.getItem(k)||''}catch(e){return''}};
const allCount=()=>teams.length;
const teamGames=id=>knownGames.filter(g=>g.team===id).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
const dateFmt=d=>{if(!d)return 'Fecha pendiente';const [y,m,day]=d.split('-');return `${day}/${m}/${y}`};
const iconOut=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9"/><path d="M20 13v6H5V5h6"/></svg>`;
function official(url=CLUB){
 try{const u=new URL(url);if(u.protocol!=='https:'||!['www.fcf.cat','fcf.cat'].includes(u.hostname))throw Error('Origen no oficial');
 if(window.LACOOPE&&typeof window.LACOOPE.openOfficial==='function'){window.LACOOPE.openOfficial(u.href);return}
 window.open(u.href,'_blank','noopener,noreferrer');
 }catch(e){toast('Solo enlaces oficiales fcf.cat')}
}
function triggerSync(){
 sourceStatus='Actualizando Amateur A y favorito desde fcf.cat…';render();
 if(window.LACOOPE&&typeof window.LACOOPE.refresh==='function'){window.LACOOPE.refresh();return}
 sourceStatus='La actualización automática solo funciona en el APK; abre la FCF para consultar los datos';render();official(COMP);
}
function teamFCFUrl(id){const u=officialSnapshots[id]?.competitionUrl;try{const x=new URL(u);if(x.protocol==='https:'&&['www.fcf.cat','fcf.cat'].includes(x.hostname))return u}catch(e){}return COMP}
function mostRecent(id){let xs=(officialSnapshots[id]?.results||[]).filter(x=>x.status==='final'&&x.date);xs.sort((a,b)=>b.date.localeCompare(a.date));return xs[0]||null}
function nextFixture(id){let now=new Date().toISOString().slice(0,10);let xs=(officialSnapshots[id]?.fixtures||[]).filter(x=>x.date&&x.date>=now);xs.sort((a,b)=>a.date.localeCompare(b.date));return xs[0]||null}
function metricLast(id){const r=mostRecent(id);return r?`${safe(r.home)} ${safe(r.score)} ${safe(r.away)}<small>${dateFmt(r.date)} · Último localizado; puede haber partidos más recientes · FCF</small>`:'Pendiente de lectura oficial'}
function metricNext(id){const r=nextFixture(id);return r?`${safe(r.home)} – ${safe(r.away)}<small>${dateFmt(r.date)} ${safe(r.time||'')} · FCF</small>`:'Pendiente de lectura oficial'}
function metricPosition(id){const snapshot=officialSnapshots[id]||{};const p=snapshot.position;return Number.isInteger(p)&&p>0?`${p}º${Number.isInteger(snapshot.points)?` · ${snapshot.points} pts`:''} (FCF)`:'Pendiente de lectura'}
function normal(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
function identifyTeam(payload){
 // Solo asociar una ficha cuando coincidan categoría, subedad, división y grupo.
 // Una asignación errónea es peor que mostrar "pendiente de lectura".
 const cat=normal(payload.category||'');
 const group=String(payload.group||'').match(/^\s*(\d{1,2})\s*$/)?.[1];
 if(!cat||!group)return null;
 const age=cat.match(/\bs(?:7|8|9|10|11|12|13|14|15|16)\b/)?.[0]||'';
 const level=cat.match(/\b(primera|segona|segunda|tercera|quarta|cuarta|preferent)\b/)?.[1]||'';
 const standard=s=>s==='segunda'?'segona':s==='cuarta'?'quarta':s;
 const categoryOf=s=>{
  if(/prebenjami/.test(s))return 'prebenjamin';
  if(/benjami/.test(s))return 'benjamin';
  if(/alevi/.test(s))return 'alevin';
  if(/infantil/.test(s))return 'infantil';
  if(/cadet/.test(s))return 'cadete';
  if(/juvenil/.test(s))return 'juvenil';
  if(/catalana|amateur/.test(s))return 'amateur';
  return '';
 };
 const candidates=teams.filter(t=>{
  const div=normal(t.division), cName=normal(t.category);
  if(String(t.group)!==group)return false;
  const family=categoryOf(div), officialFamily=categoryOf(cat);
  if(!family||!officialFamily||family!==officialFamily)return false;
  const teamAge=div.match(/\bs(?:7|8|9|10|11|12|13|14|15|16)\b/)?.[0]||'';
  if(teamAge!==age)return false;
  const divisionLevel=div.match(/\b(primera|segona|segunda|tercera|quarta|cuarta|preferent)\b/)?.[1]||'';
  if(level&&divisionLevel&&standard(level)!==standard(divisionLevel))return false;
  const teamFemale=/femenin|femeni/.test(div+' '+cName);
  const officialFemale=/femenin|femeni/.test(cat);
  if(teamFemale!==officialFemale)return false;
  return true;
 });
 return candidates.length===1?candidates[0].id:null;
}

window.LA_COOPE_receive=function(raw){
 try{
  const p=typeof raw==='string'?JSON.parse(raw):raw;
  if(p.source!=='fcf.cat'||!/^https:\/\/(?:www\.)?fcf\.cat\//.test(p.url||''))return;
  const trustedAct=p.url==='https://www.fcf.cat/ca/competicio/acta/4208561'?'infantil-s14-a':null;
  const id=identifyTeam(p)||trustedAct;let added=0;
  if(id){const saved=officialSnapshots[id]||{results:[],fixtures:[],position:null,standings:[]};
   for(const r of p.results||[]){if(!r.home||!r.away||!/^\d{4}-\d{2}-\d{2}$/.test(r.date||''))continue;
     let v={home:r.home,away:r.away,score:r.score,date:r.date,status:r.status,url:p.url};
     if(!saved.results.some(x=>x.date===v.date&&x.home===v.home&&x.away===v.away)){saved.results.push(v);added++}}
   for(const r of p.fixtures||[]){if(!r.home||!r.away||!/^\d{4}-\d{2}-\d{2}$/.test(r.date||''))continue;
     let v={home:r.home,away:r.away,date:r.date,time:r.time||'',url:p.url};
     if(!saved.fixtures.some(x=>x.date===v.date&&x.home===v.home&&x.away===v.away)){saved.fixtures.push(v);added++}}
   if(Number.isInteger(p.position)&&p.position>0){saved.position=p.position; saved.points=p.points;added++}
   if(Array.isArray(p.standings)&&p.standings.length>0){saved.standings=p.standings.slice(0,32);added++}
   if(p.pageType==='competition'&&(p.standings?.length||p.results?.length||p.fixtures?.length)&&p.url!==COMP){saved.competitionUrl=p.url;added++}
   saved.updatedAt=new Date().toISOString();saved.source=p.url;officialSnapshots[id]=saved;
   save(DATA_KEY,JSON.stringify(officialSnapshots));
  }
  sourceStatus=added?`Datos oficiales recuperados (${added}) · ${new Date().toLocaleTimeString('es-ES')}`:(p.pageType==='acta'?'Acta abierta sin datos suficientes para asignarla': 'FCF consultada, pero sin partidos verificables para este equipo; puedes volver a actualizar');
  render();
 }catch(e){sourceStatus='No se pudieron interpretar los datos de la FCF';render()}
};
window.LA_COOPE_error=function(message){sourceStatus=String(message||'No se pudo consultar la FCF');render()};
window.LA_COOPE_status=function(message){sourceStatus=String(message||'Consultando FCF…');render()};
window.LA_COOPE_syncTarget=function(){return JSON.stringify({favorite:favorite||''})};
function toast(msg){const n=document.getElementById('toast');n.textContent=msg;n.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>n.classList.remove('show'),3400)}
function choose(id){if(!teams.some(t=>t.id===id))return;favorite=id;save(KEY_FAV,id);render();toast('Favorito guardado en este dispositivo');
 if(window.LACOOPE&&typeof window.LACOOPE.favoriteChanged==='function'){window.LACOOPE.favoriteChanged(id)}
}
function pick(id){if(!teams.some(t=>t.id===id))return;selected=id;save(KEY_VIEW,id);render()}
function btnFCF(label='Abrir ficha oficial',url=CLUB,cls='btn'){return `<button class="${cls}" type="button" data-open="${safe(url)}">${safe(label)} ${iconOut}</button>`}
function teamSelect(){return `<label class="eyebrow" for="teamselect">Equipo</label><select id="teamselect" aria-label="Equipo">${teams.map(t=>`<option value="${safe(t.id)}" ${selected===t.id?'selected':''}>${safe(t.name)}</option>`).join('')}</select>`}
function summaryMetric(title,id){let v=title==='ÚLTIMO RESULTADO'?metricLast(id):title==='PRÓXIMO PARTIDO'?metricNext(id):metricPosition(id);return `<div class="metric ${title==='POSICIÓN'?'wide':''}"><div><small>${title}</small><strong>${v}</strong></div></div>`}
function archiveLine(g){return `<div class="score-item"><div><small>${safe(g.date?dateFmt(g.date):g.dateLabel)} · ${safe(byId(g.team).name)}</small><strong>${safe(g.home)}<br>${safe(g.away)}</strong><a class="muted-link" href="${safe(g.url)}" target="_blank" rel="noopener noreferrer">${safe(g.sourceType)} ↗</a></div><span class="score-box mono">${g.homeScore}–${g.awayScore}</span></div>`}
function teamHero(t){let available=teamGames(t.id)[0];return `<div class="card hero-card"><div class="strip"></div><div class="hero-head"><span class="hero-label">EL PRIMER EQUIPO</span><span class="tag dark">★ REFERENTE</span></div><h2 class="hero-title">${safe(t.name)}</h2><p class="hero-sub">${safe(t.division)} · Grupo ${safe(t.group)}</p><div class="metric-grid">${summaryMetric('ÚLTIMO RESULTADO',t.id)}${summaryMetric('PRÓXIMO PARTIDO',t.id)}${summaryMetric('POSICIÓN',t.id)}</div><div class="hero-bottom">${btnFCF('Ver calendario',teamFCFUrl(t.id))}${btnFCF('Clasificación',teamFCFUrl(t.id),'btn outline')}</div>${available?`<div class="spotlight-note">Acta/noticia histórica disponible: ${safe(available.date?dateFmt(available.date):available.dateLabel)} · ${available.homeScore}–${available.awayScore}. No se considera el último resultado.</div>`:'<div class="spotlight-note">La app intentará leer datos públicos al entrar en la FCF. Si no identifica un resultado no lo inventará.</div>'}</div>`}
function favoriteCard(){if(!favorite||!teams.some(t=>t.id===favorite))return `<div class="card"><div class="favorite-choose"><div class="section-label">☆ MI EQUIPO FAVORITO</div><h3 style="font-size:19px;letter-spacing:-.35px">¿Qué equipo quieres seguir?</h3><p class="faint" style="font-size:12px">Selecciona cualquier categoría, desde Amateur hasta Prebenjamín.</p><button class="btn" data-tab="equipos">Elegir equipo ☆</button></div></div>`;
const t=byId(favorite),g=teamGames(t.id)[0];return `<div class="card"><div class="favorite-header"><div><div class="section-label">★ MI EQUIPO FAVORITO</div><strong>${safe(t.name)}</strong><small>${safe(t.division)} · Grupo ${safe(t.group)}</small></div><button class="star" aria-label="Cambiar favorito" title="Cambiar favorito" data-tab="equipos">★</button></div><div class="favorite-body"><div class="thinmetrics"><div class="thinmetric"><small>ÚLTIMO RESULTADO</small><strong>${metricLast(t.id)}</strong></div><div class="thinmetric"><small>PRÓXIMO PARTIDO</small><strong>${metricNext(t.id)}</strong></div></div><div class="thinmetric" style="min-height:55px;margin-bottom:12px"><small>CLASIFICACIÓN</small><strong>${metricPosition(t.id)}</strong></div>${g?`<div class="mini-note">Acta histórica oficial: ${safe(g.date?dateFmt(g.date):g.dateLabel)} · ${g.homeScore}–${g.awayScore}. <a href="${safe(g.url)}" target="_blank" rel="noopener">Consultar ↗</a></div>`:''}<div class="split">${btnFCF('Ver partidos',teamFCFUrl(t.id))}<button class="btn outline-dark" data-tab="equipos">Cambiar ★</button></div></div></div>`}
function renderHome(){return `<h1 class="page-title">Tu fútbol, en un lugar.</h1><p class="page-sub">Sigue al Ciutat Cooperativa y a tu equipo favorito.</p>${`<div class="notice"><b>Lectura FCF:</b> ${safe(sourceStatus)} <button class="btn" type="button" data-sync="yes" style="margin:9px 0 0">↻ Actualizar</button></div>`}${teamHero(byId(MAIN_TEAM))}${favoriteCard()}<div class="row" style="margin-top:23px"><h3 class="list-head" style="margin:0">Actas oficiales localizadas</h3><span class="tag">Histórico</span></div><p class="page-sub" style="margin:7px 0 10px">Resultados contrastados en fcf.cat. No necesariamente los más recientes.</p><div class="card">${knownGames.slice(0,3).map(archiveLine).join('')}</div><div class="notice"><b>Actualización:</b> al abrir LA COOPE se intenta consultar automáticamente el Amateur A y tu favorito desde la FCF. Si la web cambia o no permite identificar categoría y grupo, se conservarán los últimos datos verificados y se indicará el error. El botón Actualizar permite reintentar.</div>${btnFCF('Portal de competiciones FCF',COMP,'btn full')}<div style="margin-top:10px">${btnFCF('Probar con acta oficial 4–0 (Infantil S14)',ACT_EXAMPLE,'btn outline')}</div><footer>LA COOPE · Temporada 2026/27 · Club FCF 2899</footer>`}
function renderPartidos(){let t=byId(selected),f=officialSnapshots[t.id]?.fixtures||[];
 const next=f.filter(x=>x.date>=new Date().toISOString().slice(0,10)).sort((a,b)=>a.date.localeCompare(b.date));
 return `<h1 class="page-title">Calendario y directo</h1><p class="page-sub">Partidos detectados en páginas oficiales</p><div class="card" style="padding:15px">${teamSelect()}<p class="faint" style="font-size:11px;margin:9px 0 0">${safe(t.division)} · Grupo ${safe(t.group)}</p></div><div class="card">${next.length?next.slice(0,20).map(g=>`<div class="score-item"><div><small>${dateFmt(g.date)} · ${safe(g.time||'Hora pendiente')}</small><strong>${safe(g.home)} – ${safe(g.away)}</strong></div><a class="muted-link" href="${safe(g.url)}">FCF ↗</a></div>`).join(''):`<div class="table-empty"><span>▦</span><h3>Próximo encuentro no verificado</h3><p>La app aún no ha identificado un calendario completo para este grupo. Consulta el portal de competiciones de la FCF.</p>${btnFCF('Consultar calendario FCF',teamFCFUrl(t.id))}</div>`}</div><div class="callout"><strong>Seguimiento en directo</strong><p>Abre el partido correspondiente desde la competición. Solo habrá marcador en directo si la FCF publica esa información.</p>${btnFCF('Abrir competición FCF',teamFCFUrl(t.id))}</div>`}
function renderResults(){const g=filterGames==='equipo'?teamGames(selected):[...knownGames].sort((a,b)=>(b.date||'').localeCompare(a.date||''));return `<h1 class="page-title">Resultados oficiales</h1><p class="page-sub">Actas y noticias verificadas · Temporada 2026/27</p><div class="pill-row"><button class="pill ${filterGames==='todos'?'selected':''}" data-results="todos">Todos</button><button class="pill ${filterGames==='equipo'?'selected':''}" data-results="equipo">Un equipo</button></div>${filterGames==='equipo'?`<div class="card" style="padding:15px">${teamSelect()}</div>`:''}<div class="notice"><b>Importante:</b> estos son partidos históricos localizados en la FCF. No constituyen el historial completo ni el último resultado actual de cada equipo.</div>${g.length?`<div class="card">${g.map(archiveLine).join('')}</div>`:`<div class="card empty-state"><strong>Sin actas verificadas</strong>Prueba otro equipo o consulta el portal oficial.</div>`}${btnFCF('Ver todos los resultados FCF',COMP,'btn full')}`}
function renderClassification(){let t=byId(selected),snap=officialSnapshots[t.id]||{},rows=Array.isArray(snap.standings)?snap.standings:[];
 return `<h1 class="page-title">Clasificación</h1><p class="page-sub">Solo tablas reconocidas desde el portal oficial</p><div class="card" style="padding:15px">${teamSelect()}<p class="faint" style="font-size:11px;margin:9px 0 0">${safe(t.division)} · Grupo ${safe(t.group)}</p></div><div class="card"><table class="stand-table"><thead><tr><th>POS.</th><th>EQUIPO</th><th>PJ</th><th>PTS</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${safe(r.position)}</td><td>${safe(r.team)}</td><td>${safe(r.played??'—')}</td><td>${safe(r.points??'—')}</td></tr>`).join('')}</tbody></table>${rows.length?'':`<div class="table-empty"><span>≡</span><h3>Tabla pendiente de lectura</h3><p>Solo se completará cuando podamos identificar con seguridad una clasificación de este grupo en la web federativa.</p>${btnFCF('Seleccionar competición en la FCF',teamFCFUrl(t.id))}</div>`}</div><div class="notice">Las posiciones pueden cambiar al actualizarse las actas. La última tabla reconocida se conserva localmente con su fecha de consulta.</div>`}
const categories=['Todos','Amateur','Juvenil','Cadete','Infantil','Alevín','Benjamín','Prebenjamín','Femenino'];
function renderTeams(){let visible=teams.filter(t=>(category==='Todos'||t.category===category)&&(!search||(t.name+' '+t.division).toLocaleLowerCase('es').includes(search.toLocaleLowerCase('es'))));return `<h1 class="page-title">Los equipos</h1><p class="page-sub">${allCount()} equipos · Elige tu favorito con la estrella</p><div class="toolbar"><input id="teams-search" type="search" placeholder="Buscar equipo o categoría…" value="${safe(search)}" autocomplete="off" aria-label="Buscar equipos"></div><div class="pill-row">${categories.map(c=>`<button class="pill ${category===c?'selected':''}" data-category="${safe(c)}">${safe(c)}</button>`).join('')}</div><div class="card">${visible.length?visible.map((t,i)=>`<div class="team-row"><span class="team-number">${t.name.includes('Amateur')?'A':t.name.slice(0,1)}</span><div class="team-info"><strong>${safe(t.name)}</strong><small>${safe(t.division)} · Grupo ${safe(t.group)}</small></div><div class="team-actions"><button class="text-button" data-pick="${safe(t.id)}">Ver</button><button class="team-fav ${favorite===t.id?'on':''}" data-fav="${safe(t.id)}" aria-label="${favorite===t.id?'Favorito actual':'Marcar como favorito'} ${safe(t.name)}">${favorite===t.id?'★':'☆'}</button></div></div>`).join(''):`<div class="empty-state"><strong>No se encontraron equipos</strong>Prueba otra categoría.</div>`}</div><div class="callout"><strong>Club Ciutat Cooperativa</strong><p>El listado corresponde a la estructura de equipos recogida para 2026/27. Algunos grupos y denominaciones pueden cambiar durante la temporada.</p>${btnFCF('Consultar clubes en la FCF',CLUB)}</div>`}
function render(){const view=document.getElementById('view');view.innerHTML=({inicio:renderHome,partidos:renderPartidos,resultados:renderResults,clasificacion:renderClassification,equipos:renderTeams}[tab]||renderHome)();document.querySelectorAll('.nav-link').forEach(b=>{let active=b.dataset.tab===tab;b.classList.toggle('active',active);if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')})}
function navigate(t){if(!['inicio','partidos','resultados','clasificacion','equipos'].includes(t))return;tab=t;render();window.scrollTo({top:0,behavior:'instant'});}
document.addEventListener('click',e=>{const el=e.target.closest('button');if(!el){const a=e.target.closest('a[href]');if(a&&/^https:\/\/www\.fcf\.cat\//.test(a.href)){e.preventDefault();official(a.href)}return}if(el.dataset.tab)navigate(el.dataset.tab);if(el.dataset.sync)triggerSync();if(el.dataset.open)official(el.dataset.open);if(el.dataset.fav)choose(el.dataset.fav);if(el.dataset.pick){pick(el.dataset.pick);navigate('partidos')}if(el.dataset.category){category=el.dataset.category;render()}if(el.dataset.results){filterGames=el.dataset.results;render()}});
document.addEventListener('change',e=>{if(e.target.id==='teamselect')pick(e.target.value)});
document.addEventListener('input',e=>{if(e.target.id==='teams-search'){
 search=e.target.value;
 const cursor=e.target.selectionStart;
 render();
 const next=document.getElementById('teams-search');
 if(next){next.focus();if(cursor!==null)next.setSelectionRange(cursor,cursor)}
}});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;document.getElementById('install-button').hidden=false});
document.getElementById('install-button').addEventListener('click',async()=>{if(!installPrompt){toast('En Chrome: ⋮ → Instalar aplicación o Añadir a pantalla de inicio');return}await installPrompt.prompt();installPrompt=null;document.getElementById('install-button').hidden=true});
window.addEventListener('appinstalled',()=>toast('LA COOPE instalada correctamente'));
async function bootstrap(){try{
 if(window.LA_COOPE_INLINE){teams=window.LA_COOPE_INLINE.teams;knownGames=window.LA_COOPE_INLINE.verified.games}
 else {const [tt,vv]=await Promise.all([fetch('./teams.json').then(r=>r.json()),fetch('./verified.json').then(r=>r.json())]);teams=tt;knownGames=vv.games}
 favorite=load(KEY_FAV); selected=load(KEY_VIEW)||MAIN_TEAM;try{officialSnapshots=JSON.parse(load(DATA_KEY)||load(OLD_DATA_KEY)||'{}')}catch(e){officialSnapshots={}}
 if(!teams.some(t=>t.id===selected))selected=MAIN_TEAM;
 if(!teams.some(t=>t.id===favorite))favorite='';
 render();if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
}catch(err){document.getElementById('view').innerHTML='<div class="card" style="padding:18px"><h2>No se pudieron abrir los datos locales</h2><p>Prueba a publicar o abrir la versión de demostración de LA COOPE.</p></div>';console.error(err)}}
bootstrap();
