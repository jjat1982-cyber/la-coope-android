/* LA COOPE 9.3 - Lectura local de datos que muestra fcf.cat.
   No usa servidores intermediarios, credenciales, APIs privadas ni peticiones a otros dominios.
   Devuelve únicamente información identificable en el DOM actual; NO garantiza cobertura completa. */
(function(){
  try {
    const host=(location.hostname||'').toLowerCase();
    if(host!=='fcf.cat' && host!=='www.fcf.cat') return JSON.stringify({source:'fcf.cat',error:'Origen no permitido'});
    if(location.protocol!=='https:') return JSON.stringify({source:'fcf.cat',error:'Se requiere HTTPS'});
    const norm=x=>String(x??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
    const raw=document.body ? String(document.body.innerText||'') : '';
    const body=norm(raw);
    const lines=raw.split(/[\r\n]+/).map(norm).filter(Boolean);
    const ret={source:'fcf.cat',url:location.href,pageType:'other',category:'',group:'',results:[],fixtures:[],position:null,points:null,standings:[],links:[],coverage:'partial'};
    if(/^\s*(?:Internal Server Error|Bad Gateway|Service Unavailable|500 Internal Server Error)\s*$/i.test(body)){
      return JSON.stringify({...ret,error:'La página solicitada devuelve un error del servidor FCF'});
    }
    if(!body) return JSON.stringify({...ret,error:'La página aún no muestra datos'});

    // FCF ACTA: COMPETICIÓ/INFANTIL PRIMERA DIVISIÓ S14/GRUP 11/Jornada 3
    const comp=body.match(/COMPETICI[ÓO]N?\s*\/\s*([^/]{3,120}?)\s*\/\s*GRUP(?:O)?\s*(\d{1,2})\b/i)
      ||body.match(/(?:CATEGORIA|COMPETICI[ÓO]N?)\s*:?\s*([^\n/]{3,120}?)\s*(?:GRUP(?:O)?\s*(\d{1,2}))/i);
    if(comp){ret.category=norm(comp[1]);ret.group=comp[2]}
    const isAct=/\/competicio\/acta\/\d+/i.test(location.pathname);
    if(isAct)ret.pageType='acta';
    else if(/\/competicio(?:\/|$)/.test(location.pathname))ret.pageType='competition';
    else if(/\/clubs(?:\/|$)/.test(location.pathname))ret.pageType='clubs';
    // Some FCF pages provide category in title/heading without the breadcrumb.
    if(!ret.category){
      const candidates=[...document.querySelectorAll('h1,h2,h3,[class*="competicio"],[class*="competition"]')]
        .map(n=>norm(n.innerText)).filter(x=>x.length>5&&x.length<120);
      for(const c of candidates){
        if(/primera catalana|quarta catalana|juvenil|cadet|infantil|alev[ií]|benjam[ií]|prebenjam[ií]/i.test(c)){
          ret.category=c;break;
        }
      }
    }
    if(!ret.group && /GRUP(?:O)?\s*\d{1,2}/i.test(body))ret.group=(body.match(/\bGRUP(?:O)?\s*(\d{1,2})\b/i)||[])[1]||'';
    // Competition selectors are the most authoritative category/group context on FCF pages.
    if(!isAct){
      const selectValues=[...document.querySelectorAll('select')].map(x=>norm(x.selectedOptions?.[0]?.textContent||x.options?.[x.selectedIndex]?.text||'')).filter(Boolean);
      const contextLines=selectValues.concat(lines.slice(0,50));
      const groupText=contextLines.find(x=>/^GRUP\s*\d{1,2}$/i.test(x));
      if(groupText)ret.group=(groupText.match(/\d+/)||[])[0]||ret.group;
      const patterns=/(?:PRIMERA|SEGONA|TERCERA|QUARTA)\s+CATALANA|(?:JUVENIL|CADET|CADETE|INFANTIL|ALEVI|ALEV[IÍ]|BENJAMI|BENJAM[IÍ]|PREBENJAMI|PREBENJAM[IÍ]|FEMEN[IÍ])[^\n]{0,90}/i;
      const chosen=contextLines.find(x=>patterns.test(x)&&x.length<110&& !/SELECTOR|COMPETICIONS FUTBOL/i.test(x));
      if(chosen)ret.category=norm(chosen);
    }

    const dateOf=s=>{
      const m=String(s).match(/(?:^|[^\d])(\d{1,2})[.\/-](\d{1,2})[.\/-](20\d{2})(?!\d)/);
      if(!m)return '';
      const d=Number(m[1]),mon=Number(m[2]),y=Number(m[3]);
      if(mon<1||mon>12||d<1||d>new Date(y,mon,0).getDate())return '';
      return `${y}-${String(mon).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    };
    const timeOf=s=>{const m=String(s).match(/\b(?:[01]?\d|2[0-3])[:.][0-5]\d\s*(?:H|H\b)?/i);if(!m)return '';
       const p=m[0].replace(/\s*H.*$/i,'').replace('.',':');return p.length===4?'0'+p:p;
    };
    const hasClub=s=>/\b(?:CIUDAD|CIUTAT)\s+COOPERATIVA\b/i.test(norm(s));
    const unique=new Set();
    const add=(obj,completed)=>{
      if(!obj.home||!obj.away||!obj.date||!hasClub(obj.home+' '+obj.away))return;
      const home=norm(obj.home),away=norm(obj.away);if(home===away||home.length>130||away.length>130)return;
      const key=[obj.date,home,away].join('|');if(unique.has(key))return;unique.add(key);
      if(completed){
        if(!/^\d{1,2}-\d{1,2}$/.test(obj.score||''))return;
        ret.results.push({home,away,date:obj.date,score:obj.score,status:'final'});
      }else ret.fixtures.push({home,away,date:obj.date,time:obj.time||''});
    };
    if(isAct){
      const dateLine=lines.find(x=>/^(?:Data|Fecha|Date)\s*:/i.test(x))||'';
      const dt=dateOf(dateLine);
      const closedIndex=lines.findIndex(x=>/^(?:Acta Tancada|Acta Cerrada|Match Report Closed)$/i.test(x));
      // Team names are immediately around the act's status/score banner.
      if(closedIndex>0 && dt){
        const home=lines[closedIndex-1];
        let score='',after=-1;
        for(let i=closedIndex+1;i<Math.min(closedIndex+6,lines.length);i++){
          const sm=lines.slice(closedIndex+1,i+1).join(' ').match(/\b(\d{1,2})\s*[-–]\s*(\d{1,2})\b/);
          if(sm){score=sm[1]+'-'+sm[2];after=i;break;}
        }
        if(score && after>=0 && after+1<lines.length){
          const away=lines[after+1];
          if(hasClub(home+' '+away))add({home,away,score,date:dt},true);
        }
      }
    }
    // FCF renders results primarily as independent responsive CARDS (not <table> rows).
    // Restrict each candidate to a single compact match: status, date, score and two team names.
    // We don't infer results merely from finding "CIUDAD COOPERATIVA" in an unrelated part of the page.
    if(!isAct){
      const scoreRx=/^(\d{1,2})\s*[-–]\s*(\d{1,2})$/;
      const badTeam=/^(?:ACTA TANCADA|ACTA ABIERTA|RESULTATS|CALENDARI|CLASSIFICACI[ÓO]|JORNADA|GRUP\s*\d+|INFORMACI[ÓO] DEL CAMP|CAMP DE FUTBOL|COMPETICI[ÓO]|DATA|HORA|ESTADI|PRIMERA CATALANA)$/i;
      const isTeam=x=>{
        const z=norm(x);
        return z.length>=4&&z.length<=100&&/[A-Za-zÀ-ÿ]{3}/.test(z)&&!/\d{1,2}[.\/-]\d{1,2}[.\/-]20\d\d/.test(z)
          &&!badTeam.test(z)&&!/^\d+\s*[-–]\s*\d+$/.test(z)&&!/^\d{1,2}:\d\d$/.test(z)
          &&!/^(?:EN DIRECTE|PENDENT|AJORNAT|SUSP[ÈE]S|FINALITZAT|ACTA|EQUIPS|RESULTAT)/i.test(z);
      };
      const parts=lines;
      for(let i=0;i<parts.length;i++){
        if(!scoreRx.test(parts[i]))continue;
        const windowStart=Math.max(0,i-8),windowEnd=Math.min(parts.length,i+8);
        const near=parts.slice(windowStart,windowEnd);
        if(!near.some(x=>/ACTA TANCADA|ACTA CERRADA|FINALITZAT/i.test(x)))continue;
        const score=parts[i].match(scoreRx);
        const dates=near.map(dateOf).filter(Boolean);
        if(!dates.length)continue;
        // Official responsive card layout: HOME | ACTA TANCADA | DATE | TIME | SCORE | AWAY.
        const above=parts.slice(Math.max(0,i-7),i).filter(isTeam).filter(x=>!/ACTA|CAMP|INFORMACI|JORNADA/i.test(x));
        const below=parts.slice(i+1,Math.min(parts.length,i+6)).filter(isTeam);
        let home=above.length?above[above.length-1]:'';
        let away=below.length?below[0]:'';
        // Conservative fallback: first plausible team before the act banner, first after the score.
        if(!home){const beforeStatus=above.filter(x=>!/^\d/.test(x));home=beforeStatus[0]||'';}
        if(!away)away=below[0]||'';
        if(!hasClub(home+' '+away))continue;
        if(home&&away)add({home,away,date:dates[0],score:score[1]+'-'+score[2]},true);
      }
      // Future fixtures may have a date/time but no closed-act score.
      for(let i=0;i<parts.length;i++){
        const dt=dateOf(parts[i]);if(!dt)continue;
        const day=parts.slice(Math.max(0,i-4),Math.min(parts.length,i+9));
        if(!day.some(hasClub)||day.some(x=>/ACTA TANCADA/i.test(x)))continue;
        const names=day.filter(isTeam).filter(x=>!/^(?:CAMP|JORNADA|DIA|PARTIT)/i.test(x));
        const clubIndex=names.findIndex(hasClub);
        if(clubIndex<0 || names.length<2)continue;
        const opponent=names.find((x,j)=>j!==clubIndex && /[A-Za-zÀ-ÿ]/.test(x));
        if(!opponent)continue;
        let home=names[0],away=names[1];
        if(!hasClub(home+' '+away))continue;
        add({home,away,date:dt,time:timeOf(day.join(' '))},false);
      }
    }
    // Competitions may render HTML tables or ARIA tables. Ignore lineup/goal tables on act pages.
    if(!isAct){
      const rows=[...document.querySelectorAll('table tr,[role="row"]')].slice(0,500);
      for(const row of rows){
        const cells=[...row.querySelectorAll('td,[role="cell"]')].map(n=>norm(n.innerText)).filter(Boolean);
        if(cells.length<3 || !hasClub(cells.join(' ')))continue;
        const str=cells.join(' | '),dt=dateOf(str);
        if(!dt)continue;
        // Require two distinguishable team cells, not an act/score/date label.
        const candidates=cells.filter(c=>!dateOf(c)&&!/^\d{1,2}\s*[-–]\s*\d{1,2}$/.test(c)&&!/^\d+(?:[:.]\d+)?H?$/i.test(c)&&!/^(?:Jornada|Acta|Camp|Hora|Estadi|Data|Grup)\b/i.test(c)&&/[a-zÀ-ÿ]{3}/i.test(c));
        if(candidates.length<2)continue;
        let teamPos=candidates.findIndex(c=>hasClub(c));
        if(teamPos<0)continue;
        // Results listed left to right; restrict team names around the home club.
        const others=candidates.filter((c,i)=>i!==teamPos&&c.length<=100);
        const home=candidates[0],away=candidates[1];
        if(!hasClub(home+' '+away))continue;
        const scored=cells.find(c=>/^\d{1,2}\s*[-–]\s*\d{1,2}$/.test(c));
        const score=scored?scored.match(/(\d{1,2})\s*[-–]\s*(\d{1,2})/):null;
        if(score)add({home,away,date:dt,score:score[1]+'-'+score[2]},true);
        else add({home,away,date:dt,time:timeOf(str)},false);
      }
      // Only read a position when the table explicitly identifies itself as standings/classification.
      for(const table of [...document.querySelectorAll('table')].slice(0,30)){
        const context=norm((table.previousElementSibling?.innerText||'')+' '+(table.querySelector('thead')?.innerText||'')+' '+(table.getAttribute('aria-label')||''));
        if(!/classificaci[oó]|clasificaci[oó]|punts|puntos|\bpts\b/i.test(context))continue;
        const header=[...table.querySelectorAll('thead th')].map(x=>norm(x.innerText));
        const teamCol=header.findIndex(h=>/equip|club/i.test(h));
        const playedCol=header.findIndex(h=>/^(?:pj|j|jugats|jugados|partits)$/i.test(h));
        const pointsCol=header.findIndex(h=>/^(?:pts|pt|punts|puntos)$/i.test(h));
        const standings=[];
        for(const row of [...table.querySelectorAll('tr')]){
          const cs=[...row.querySelectorAll('td')].map(n=>norm(n.innerText));
          if(cs.length<3)continue;
          const first=cs[0].match(/^\s*(\d{1,2})\s*\.?\s*$/);
          if(!first||Number(first[1])<1||Number(first[1])>32)continue;
          const team=cs[teamCol>=0&&teamCol<cs.length?teamCol:1];
          if(!team||!/[a-zÀ-ÿ]/i.test(team))continue;
          const pj=Number(cs[playedCol>=0&&playedCol<cs.length?playedCol:2]);
          const pts=Number(cs[pointsCol>=0&&pointsCol<cs.length?pointsCol:cs.length-1]);
          standings.push({position:Number(first[1]),team:team.slice(0,110),played:Number.isInteger(pj)?pj:null,points:Number.isInteger(pts)?pts:null});
        }
        if(standings.some(x=>hasClub(x.team))){
          ret.standings=standings;
          const me=standings.find(x=>hasClub(x.team));
          ret.position=me.position;ret.points=me.points;
          break;
        }
      }
    }
    const allowedLink=u=>{try{let x=new URL(u,location.href);return x.protocol==='https:'&&['www.fcf.cat','fcf.cat'].includes(x.hostname)&&/\/ca\/(?:competicio|clubs)/.test(x.pathname)?x.href:''}catch(_){return ''}};
    ret.links=[...new Set([...document.querySelectorAll('a[href]')].map(a=>allowedLink(a.getAttribute('href'))).filter(Boolean))].slice(0,70);
    return JSON.stringify(ret);
  } catch(e) {
    return JSON.stringify({source:'fcf.cat',url:location.href,error:'Error de lectura: '+String(e.message).slice(0,120),results:[],fixtures:[]});
  }
})()
