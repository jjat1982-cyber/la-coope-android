# LA COOPE V9.2 — Android local (beta)

**Cambios:** se ha eliminado el enlace roto a `/ca/clubs/2899/categories/54313994` y se usa el selector oficial `https://www.fcf.cat/ca/competicio` para ver jornadas, marcadores y clasificación. Un WebView de Android lee exclusivamente el contenido visible de `fcf.cat` y permite guardar las actas y las tablas que reconoce.

## Qué puede hacer

- Primer equipo Amateur A fijo arriba y favorito elegido manualmente debajo.
- 27 equipos, colores amarillo/negro y escudo original.
- Abre el portal oficial de competiciones y permite navegar hasta una categoría y grupo. Pulsa **LEER** para interpretar la página visible.
- Reconoce actas cerradas con local, visitante, marcador, fecha, categoría y grupo. Una prueba accesible de forma independiente es https://www.fcf.cat/ca/competicio/acta/4208561 (Infantil S14 A 4-0 Can Vidalet, 11-10-2026).
- Intenta reconocer calendarios, marcadores y clasificaciones en tablas HTML oficiales, siempre que las muestre el sitio.
- Guarda localmente resultados localizados, clasificación y vínculo de competición, sin introducir marcadores inventados.

## Limitaciones técnicas verificadas

La FCF publica páginas HTML dinámicas y no se ha verificado que los calendarios de todos los equipos se encuentren presentes como tablas legibles por WebView. **Esta versión no garantiza ni ha demostrado obtener automáticamente último partido, siguiente partido y clasificación de los 27 equipos.** Un acta aislada solo sirve para mostrar el último resultado **localizado**, no necesariamente el último realmente jugado. No ofrece vídeo en directo salvo que la FCF lo publique y el usuario lo abra. No accede a APIs privadas ni ignora restricciones del servidor.

## Pasos para usar

1. Abre LA COOPE → «Abrir competiciones y leer». Aparecerá el selector oficial de la FCF.
2. Selecciona la temporada 2026/27, la competición del equipo (por ejemplo Primera Catalana) y el grupo (Amateur A: grupo 3). Navega en la página hasta el calendario o clasificación.
3. Pulsa **LEER** en la barra amarilla; vuelve a Inicio con «← LA COOPE».
4. Selecciona tu equipo favorito en Equipos; repite la búsqueda de la competición correspondiente.
5. Para confirmar la lectura de actas, desde Inicio abre «Probar con acta oficial 4–0 (Infantil S14)» y pulsa LEER. Este resultado no debe presentarse como partido más reciente si hay actas posteriores.

## Compilación personal

Con SDK oficial Android API 36, JDK 17 y Gradle 8.13: `gradle assembleDebug`. El APK estará en `app/build/outputs/apk/debug/app-debug.apk`.

En el GitHub del usuario ya hay un workflow que descomprime el ZIP V9.1. Para compilar V9.2: subir `LA_COOPE_V9_2_Proyecto_Android.zip` y modificar el paso `Extraer proyecto` del archivo `.github/workflows/compilar-apk.yml` para descomprimir el nuevo nombre. GitHub ejecuta la compilación y muestra el artifact `LA_COOPE_APK`. Por ser APK de depuración con claves efímeras, probablemente haga falta desinstalar V9.1 antes de instalar V9.2 (se pierden favoritos guardados).

## Pruebas

`node test_v92.cjs` valida acta, seguridad de origen, tabla y fallo HTTP. `node --check` valida el código JavaScript. El usuario tendrá que confirmar el funcionamiento en el Samsung y con las páginas oficiales reales, no accesibles desde el entorno de compilación actual.
