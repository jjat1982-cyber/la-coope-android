'use strict';
const fs=require('fs');const vm=require('vm');const assert=require('node:assert/strict');
const source=fs.readFileSync('app/src/main/assets/fcf-reader.js','utf8');
function parse({text,url='https://www.fcf.cat/ca/competicio/acta/4208561',tables=[]}){
  const makeNode=(value)=>({innerText:value,querySelectorAll:()=>[],getAttribute:()=>null,previousElementSibling:null});
  const document={body:{innerText:text},querySelectorAll(q){
    if(q==='table tr,[role="row"]')return tables.flatMap(t=>t.rows);
    if(q==='table')return tables;
    return [];
  }};
  return JSON.parse(vm.runInNewContext(source,{document,location:new URL(url),URL,console},{timeout:300}));
}
function makeTable(headers,rows){
 const makeCell=(x)=>({innerText:x});
 const trs=rows.map(row=>({innerText:row.join(' '),querySelectorAll:()=>row.map(makeCell)}));
 const head={innerText:headers.join(' ')};
 return {previousElementSibling:{innerText:'CLASSIFICACIÓ'},getAttribute:()=>null,querySelector:(sel)=>sel==='thead'?head:null,querySelectorAll(sel){
  if(sel==='thead th')return headers.map(makeCell);
  if(sel==='thead')return [head];
  if(sel==='tr')return trs;
  return []},rows:trs};
}
const act=parse({text:`Acta del partit\nDetalls de l'acta\nCIUDAD COOPERATIVA, C.F.\nActa Tancada\n4 - 0\nCAN VIDALET, C.F.\nCOMPETICIÓ/INFANTIL PRIMERA DIVISIÓ S14/GRUP 11/Jornada 3\nTemporada : 2026 / 27\nData: 11.10.2026\nHora: 11.30H\nEstadi: DANI JARQUE`});
assert.equal(act.pageType,'acta');assert.equal(act.group,'11');assert.equal(act.results.length,1);assert.equal(act.results[0].score,'4-0');assert.equal(act.results[0].date,'2026-10-11');
const unrelated=parse({text:`Acta del partit\nDetalls de l'acta\nSANTFELIUENC, F.C.\nActa Tancada\n2-1\nVILA-SECA, C.F.\nCOMPETICIÓ/PRIMERA CATALANA/GRUP 3\nData: 19.09.2026`,url:'https://www.fcf.cat/ca/competicio/acta/4109128'});
assert.equal(unrelated.results.length,0);
const broken=parse({text:'Internal Server Error',url:'https://www.fcf.cat/ca/clubs/2899/categories/54313994'});
assert.match(broken.error,/servidor FCF/);
const t=makeTable(['Pos','Equip','PJ','PTS'],[['1','C.F. RIVAL','7','19'],['2','CIUDAD COOPERATIVA, C.F.','7','15'],['3','CF OTRO','7','12']]);
const table=parse({text:'COMPETICIÓ/PRIMERA CATALANA/GRUP 3\nClassificació\nPos Equip PJ PTS',url:'https://www.fcf.cat/ca/competicio/grup-3',tables:[t]});
assert.equal(table.position,2);assert.equal(table.points,15);assert.equal(table.standings.length,3);
const insecure=parse({text:'Acta Tancada',url:'http://www.fcf.cat/ca/competicio/acta/1'});assert.equal(insecure.error,'Se requiere HTTPS');
console.log('Pruebas V9.2: acta realista, partido ajeno, error HTTP, clasificación y HTTPS: OK');
