/* LA COOPE 9.3 - Búsqueda progresiva de una competición en el portal público FCF.
   Solo interactúa con la página oficial visible para un navegador. No elude accesos ni utiliza APIs privadas.
   TARGET se establece desde el Java nativo: {division,group,phase} */
(function(){
 try{
  const t=window.__COOPE_TARGET__||{};
  if(!['fcf.cat','www.fcf.cat'].includes(location.hostname))return JSON.stringify({state:'error',reason:'Dominio no oficial'});
  const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const canonical=s=>norm(s).replace(/\bcadete\b/g,'cadet').replace(/\bfemenino\b|\bfemenina\b|\bfemeni\b/g,'femeni')
    .replace(/\bdivision\b|\bdivisio\b/g,'').replace(/\bfutbol\b/g,'').replace(/\s+/g,' ').trim();
  const desired=[['2026 27','2026/27','2026-27'],[norm(t.discipline||'futbol 11')],[norm(t.division)],[`grup ${t.group}`,`grupo ${t.group}`,String(t.group)]];
  const match=(a,b,idx)=>{
   const x=norm(a),y=norm(b);if(!x||!y)return false;
   if(idx===2){const a2=canonical(x),b2=canonical(y);return x===y||a2===b2||a2.includes(b2)||b2.includes(a2)}
   if(idx===3)return x===y||x===`grup ${t.group}`||x.startsWith(`grup ${t.group} `)||x===`grupo ${t.group}`||x.startsWith(`grupo ${t.group} `)||x===String(t.group);
   return x===y||x.includes(y);
  };
  const optionsMatch=(label,idx)=>desired[idx].some(d=>match(label,d,idx));
  const selects=[...document.querySelectorAll('select')].filter(x=>x.options?.length);
  // FCF website may use native selects beneath a custom CSS layer.
  if(selects.length>=4){
   const used=new Set();
   for(let i=0;i<4;i++){
    // Some pages contain an extra language selector; use option content, not fixed select indices.
    const el=selects.find(x=>!used.has(x)&&[...x.options].some(o=>optionsMatch(o.textContent,i)));
    if(!el)return JSON.stringify({state:'waiting',step:i,reason:'Esperando opciones para '+['temporada','disciplina','categoría','grupo'][i]});
    used.add(el);
    const cur=el.selectedOptions?.[0]?.textContent||'';
    if(optionsMatch(cur,i))continue;
    const opt=[...el.options].find(o=>optionsMatch(o.textContent,i));
    if(!opt)return JSON.stringify({state:'waiting',step:i,reason:'Esperando las opciones de la competición'});
    const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value')?.set;
    if(setter)setter.call(el,opt.value);else el.value=opt.value;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    return JSON.stringify({state:'working',step:i,reason:'Seleccionado '+opt.textContent.trim()});
   }
   return JSON.stringify({state:'ready',reason:'Competición y grupo seleccionados'});
  }
  // Common custom dropdown implementations (React, select2, Radix, Bootstrap).
  const relevant=[...document.querySelectorAll('button,[role="combobox"],[aria-haspopup="listbox"],.select2-selection,.ng-select-container')]
    .filter(x=>{const s=(x.innerText||x.getAttribute('aria-label')||'').trim();return s.length<100});
  const selectedVisible=i=>relevant.some(x=>optionsMatch(x.innerText||x.getAttribute('aria-label'),i));
  const list=[...document.querySelectorAll('[role="option"],.select2-results__option,li.dropdown-item,li[role="option"]')].filter(x=>x.getBoundingClientRect().width>0);
  if(list.length){
   for(let i=0;i<4;i++){
    if(selectedVisible(i))continue;
    const opt=list.find(x=>optionsMatch(x.textContent,i));
    if(opt){opt.click();return JSON.stringify({state:'working',step:i,reason:'Opción seleccionada'});}
   }
  }
  const selected=[0,1,2,3].map(i=>selectedVisible(i));
  if(selected.every(Boolean))return JSON.stringify({state:'ready',reason:'Competición seleccionada'});
  const missing=selected.findIndex(v=>!v);
  const possible=relevant.find(x=>optionsMatch(x.innerText||'',missing))||relevant[missing];
  if(possible){possible.click();return JSON.stringify({state:'working',step:missing,reason:'Abriendo selector'});}
  // Never treat text anywhere in the page as proof of a selected group; it could be an open dropdown.
  return JSON.stringify({state:'waiting',reason:'Selector sin opciones reconocibles ('+selects.length+' listas, '+relevant.length+' controles)'});
 }catch(e){return JSON.stringify({state:'error',reason:String(e.message||e).slice(0,140)});}
})()
