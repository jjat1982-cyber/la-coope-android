# LA COOPE V9.3 — lectura automática experimental de datos FCF

Proyecto Android (Java, Android SDK 36, Gradle 8.13, JDK 17) para uso personal, sin Play Store.

## Cambios respecto a la V9.2

- La aplicación intenta leer los datos oficiales **al abrirse**, sin pulsar «LEER».
- Consulta automáticamente **Amateur A** y **el equipo favorito seleccionado**, en ese orden.
- **Actualizar** repite la consulta; no abre la FCF manualmente.
- La consulta automática navega mediante un WebView secundario dentro de `fcf.cat`, seleccionando temporada, disciplina (Fútbol 11/7), competición y grupo mediante los controles públicos.
- `fcf-reader.js` reconoce **actas**, **tarjetas de resultados cerrados**, calendarios y tablas cuando su marcado permite identificar categoría, grupo y club.
- El botón manual **LEER** ahora muestra el resultado o un error concreto mediante un aviso Android visible.
- Se conserva una caché local de lo último que pudo verificarse sin inventar marcadores.

## Limitaciones importantes

- **La automatización del selector FCF NO ha podido probarse contra la web real ni en un Samsung físico** en este entorno. Puede fallar si el selector no emplea controles HTML reconocibles o cambia su estructura.
- Las pruebas pasan con páginas de ejemplo que simulan el DOM y las tarjetas vistas en capturas, no prueban la sincronización real de los 27 equipos.
- No se ha encontrado ni utilizado una API privada, ni un proveedor de resultados, ni un proxy externo: la propia WebView consulta `https://www.fcf.cat`.
- «En directo» solo mostrará información publicada por la FCF; no se simula la retransmisión ni se garantizan marcadores minuto a minuto.
- La portada puede mostrar «Sin datos nuevos» si la FCF no facilita los datos de forma interpretable.

## Compilación con GitHub Actions

Subir el ZIP **sin descomprimir** al repositorio como `LA_COOPE_V9_3_GitHub_NUEVO.zip` y editar `.github/workflows/compilar-apk.yml` para que el paso de extracción ejecute:

```
run: unzip -o LA_COOPE_V9_3_GitHub_NUEVO.zip
```

El resto del flujo de compilación que ya funcionó para la V9.2 puede mantenerse. Se recomienda cambiar el nombre del artefacto a `LA_COOPE_V9_3_APK`.

Al guardar el commit en `main` se generará un nuevo APK de depuración si la compilación pasa. La versión 9.3 aumenta `versionCode` a 17. Una firma de depuración distinta puede obligar a desinstalar la anterior y se perderán los favoritos guardados.

## Pruebas locales

```
node test_v93.cjs
node test_v92.cjs
python validate_java.py
```

`validate_java.py` usa clases simuladas para comprobar **sintaxis Java**, no equivale a la compilación Android con SDK. El workflow de GitHub realiza la compilación real.
