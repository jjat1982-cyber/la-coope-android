package com.lacoope.santboi;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String CLUB = "https://www.fcf.cat/ca/clubs/2899/categories/54313994";
    private static final String HOME = "file:///android_asset/index.html";
    private WebView homeView, fcfView;
    private LinearLayout officialLayout;
    private Handler handler = new Handler(Looper.getMainLooper());
    private String extractor;
    private int captureGeneration = 0;
    private boolean homeReady = false;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(Color.rgb(20,20,20));
        getWindow().setNavigationBarColor(Color.rgb(20,20,20));
        FrameLayout root = new FrameLayout(this);
        homeView = new WebView(this);
        configure(homeView);
        homeView.addJavascriptInterface(new LocalBridge(), "LACOOPE");
        homeView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url) {
                if (HOME.equals(url)) { homeReady=true; handler.postDelayed(() -> { pushStatus("Consultando datos públicos de la FCF…"); if(fcfView != null)fcfView.loadUrl(CLUB); }, 900); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !HOME.equals(req.getUrl().toString());
            }
        });
        root.addView(homeView, new FrameLayout.LayoutParams(-1,-1));

        fcfView = new WebView(this);
        configure(fcfView);
        fcfView.getSettings().setAllowFileAccess(false);
        fcfView.getSettings().setAllowContentAccess(false);
        fcfView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (!req.isForMainFrame()) return false;
                return !isAllowed(req.getUrl());
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (isAllowed(Uri.parse(url))) {
                    int id=++captureGeneration;
                    for(long delay : new long[]{900,2500,6000})handler.postDelayed(() -> {
                        if(id==captureGeneration && fcfView != null && fcfView.getUrl() != null && isAllowed(Uri.parse(fcfView.getUrl()))) readOfficialPage();
                    },delay);
                }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if(request.isForMainFrame())pushStatus("No se pudo abrir la página oficial");
            }
        });
        officialLayout = new LinearLayout(this);
        officialLayout.setOrientation(LinearLayout.VERTICAL);
        officialLayout.setBackgroundColor(Color.WHITE);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setPadding(8,6,8,6);
        toolbar.setBackgroundColor(Color.rgb(255,202,6));
        Button back = new Button(this);
        back.setText("← LA COOPE");
        back.setOnClickListener(v -> returnHome());
        toolbar.addView(back,new LinearLayout.LayoutParams(0,-2,1));
        TextView title = new TextView(this);
        title.setText("Página oficial"); title.setTextColor(Color.BLACK);
        title.setTextSize(13); title.setPadding(8,17,8,0);
        toolbar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button read = new Button(this);
        read.setText("Leer");
        read.setOnClickListener(v -> readOfficialPage());
        toolbar.addView(read,new LinearLayout.LayoutParams(0,-2,1));
        officialLayout.addView(toolbar);
        officialLayout.addView(fcfView,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(officialLayout, new FrameLayout.LayoutParams(-1,-1));
        officialLayout.setVisibility(View.GONE);
        setContentView(root);
        try{extractor=readAsset("fcf-reader.js");}catch(Exception e){extractor="";}
        homeView.loadUrl(HOME);
    }
    private void configure(WebView v){
        WebSettings s=v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        v.setBackgroundColor(Color.WHITE);
    }
    private static boolean isAllowed(Uri uri){
        if(uri==null || !"https".equals(uri.getScheme()))return false;
        String h=uri.getHost();
        return "fcf.cat".equals(h) || "www.fcf.cat".equals(h);
    }
    private final class LocalBridge{
        @JavascriptInterface public void openOfficial(String url){handler.post(() -> showOfficial(url));}
        @JavascriptInterface public void sync(){handler.post(() -> showOfficial(CLUB));}
    }
    private void showOfficial(String url){
        Uri uri=Uri.parse(url);
        if(!isAllowed(uri)){pushStatus("Solo se permiten páginas oficiales de la FCF");return;}
        officialLayout.setVisibility(View.VISIBLE);
        fcfView.loadUrl(url);
    }
    private void readOfficialPage(){
        if(fcfView==null || fcfView.getUrl()==null || !isAllowed(Uri.parse(fcfView.getUrl())) || extractor.isEmpty())return;
        fcfView.evaluateJavascript(extractor, value -> {
            try{
                Object decoded=new JSONTokener(value).nextValue();
                if(!(decoded instanceof String))return;
                String json=(String)decoded;
                JSONObject obj=new JSONObject(json);
                if(!"fcf.cat".equals(obj.optString("source")))return;
                if(!isAllowed(Uri.parse(obj.optString("url"))))return;
                if(obj.has("error")){pushStatus("FCF: "+obj.optString("error"));return;}
                String wrapped=JSONObject.quote(json);
                if(homeReady)homeView.evaluateJavascript("window.LA_COOPE_receive("+wrapped+");",null);
            }catch(Exception e){pushStatus("La estructura de la página no se ha podido leer");}
        });
    }
    private void pushStatus(String s){
        if(homeReady && homeView!=null)homeView.evaluateJavascript("window.LA_COOPE_error("+JSONObject.quote(s)+");", null);
    }
    private String readAsset(String name) throws Exception{
        try(InputStream in=getAssets().open(name); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1)out.write(b,0,n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
    private void returnHome(){
        officialLayout.setVisibility(View.GONE);
        if(fcfView!=null)readOfficialPage();
    }
    @Override public void onBackPressed(){
        if(officialLayout.getVisibility()==View.VISIBLE){
            if(fcfView.canGoBack()){ fcfView.goBack(); } else {returnHome();}
        } else {super.onBackPressed();}
    }
    @Override protected void onDestroy(){
        captureGeneration++;
        if(fcfView!=null){fcfView.destroy();fcfView=null;}
        if(homeView!=null){homeView.destroy();homeView=null;}
        super.onDestroy();
    }
}