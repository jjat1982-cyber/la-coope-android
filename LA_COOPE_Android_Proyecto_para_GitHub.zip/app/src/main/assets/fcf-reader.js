(function(){
try {
 const norm=s=>String(s||'').replace(/\s+/g,' ').trim();
 const body=norm(document.body.innerText||'');
 const raw=document.body.innerText||'';
 const ret={source:'fcf.cat',url:location.href,category:'',group:'',pageType:'other',results:[],fixtures:[],position:null,links:[]};
 if(location.hostname!=='www.fcf.cat'&&location.hostname!=='fcf.cat')return JSON.stringify({error:'Origen no permitido'});
 if(body.length<30)return JSON.stringify(ret);
 let match=body.match(/COMPETICI[ÓO]N?\s*\/\s*([^\n\/]+)\s*\/\s*GRUP(?:O)?\s*(\d+)/i);
 if(!match)match=body.match(/COMPETICI[ÓO]N?\s*\/\s*([^\n\/]+)\s*\/\s*GRUPO\s*(\d+)/i);
 if(match){ret.category=norm(match[1]);ret.group=match[2]}
 else{
   const meta=raw.match(/(?:PRIMERA|SEGONA|TERCERA|QUARTA)[^\n]{0,75}|(?:PREBENJAM[IÍ]|BENJAM[IÍ]|ALEV[IÍ]|INFANTIL|CADET|JUVENIL)[^\n]{0,75}/i);
   if(meta)ret.category=norm(meta[0]);
   const gr=body.match(/\bGRUP(?:O)?\s*(\d{1,2})\b/i);if(gr)ret.group=gr[1];
 }
 const dateRaw=body.match(/(?:Data|Fecha)\s*:?\s*(\d{1,2})[.\/-](\d{1,2})[.\/-](20\d{2})/i);
 let date=dateRaw?dateRaw[3]+'-'+dateRaw[2].padStart(2,'0')+'-'+dateRaw[1].padStart(2,'0'):'';
 // Acta pages have the documented structure: home, Acta Tancada, score, away
 if(/\/competicio\/acta\//i.test(location.pathname)){
  ret.pageType='acta';
  const teamScore=raw.match(/\n([^\n]+)\n\s*Acta\s+Tancada\s*\n\s*(\d+)\s*[-–]\s*(\d+)\s*\n\s*([^\n]+)/i);
  if(teamScore&&date&&/CIUDAD COOPERATIVA|CIUTAT COOPERATIVA/i.test(teamScore[1]+' '+teamScore[4])){ret.results.push({home:norm(teamScore[1]),away:norm(teamScore[4]),score:teamScore[2]+'-'+teamScore[3],date,status:'final'})}
 }
 // Generic fixture rows; rejects ambiguously formatted lines.
 const unique=new Set();
 for(const tr of [...document.querySelectorAll('tr,[role="row"]')].slice(0,120)){
  const cols=[...tr.querySelectorAll('td,[role="cell"]')].map(x=>norm(x.innerText)).filter(Boolean);
  if(cols.length<3)continue;
  const joined=cols.join(' | ');
  if(!/CIUDAD COOPERATIVA|CIUTAT COOPERATIVA/i.test(joined))continue;
  const d=joined.match(/\b(\d{1,2})[.\/-](\d{1,2})[.\/-](20\d{2})\b/);
  if(!d)continue;
  const dt=d[3]+'-'+d[2].padStart(2,'0')+'-'+d[1].padStart(2,'0');
  const teams=cols.filter(x=>x.length>=4&&!/^\d|ACTA|JORNADA|CAMP|GRUP/i.test(x));
  if(teams.length<2)continue;
  const home=teams[0].slice(0,96),away=teams[1].slice(0,96);
  const score=joined.match(/\b(\d{1,2})\s*[-–]\s*(\d{1,2})\b/);
  const key=dt+home+away;if(unique.has(key))continue;unique.add(key);
  if(score)ret.results.push({home,away,score:score[1]+'-'+score[2],date:dt,status:'final'});
  else ret.fixtures.push({home,away,date:dt,time:(joined.match(/\b(?:[01]?\d|2[0-3]):[0-5]\d\b/)||[])[0]||''});
 }
 // Classification: one row holding the club and position in its first cells
 for(const tr of [...document.querySelectorAll('tr,[role="row"]')].slice(0,120)){
  if(!/CIUDAD COOPERATIVA|CIUTAT COOPERATIVA/i.test(tr.innerText))continue;
  const cells=[...tr.querySelectorAll('td,[role="cell"]')].map(c=>norm(c.innerText));
  if(cells.length<4)continue;
  const n=Number(cells[0].replace(/[^\d]/g,''));
  if(Number.isInteger(n)&&n>=1&&n<=32){ret.position=n;break}
 }
 ret.links=[...new Set([...document.querySelectorAll('a[href]')].map(a=>a.href).filter(h=>/^https:\/\/www\.fcf\.cat\/ca\/(?:clubs|competicio)/.test(h)))].slice(0,60);
 return JSON.stringify(ret);
}catch(e){return JSON.stringify({source:'fcf.cat',error:String(e.message).slice(0,120),results:[],fixtures:[]})}
})()