# LA COOPE V9.1 — Android personal (beta)

Proyecto Android nativo para consultar exclusivamente la Federación Catalana de Futbol. Usa WebView oficial y un lector DOM limitado a contenido visible de fcf.cat. Se guardan en el dispositivo favoritos y resultados extraídos.

**Advertencia:** El lector no está validado contra la web real 2026/27 ni probado en un teléfono. Puede no detectar resultados, horarios o tablas. No implica conexión oficial autorizada, ni datos en vivo garantizados. Nunca se generan marcadores ficticios.

**Compilación**: GitHub Actions → `android-apk.yml` → archivo `LA_COOPE_V9_APK`. También se puede ejecutar `gradle assembleDebug` con Android SDK 36 y Gradle 8.13. El APK es de instalación local, no se publica en Play Store.

**Interacción**: Inicio mantiene Amateur A arriba. Al abrir la app se intenta consultar la ficha pública del club en segundo plano. Elige tu favorito en Equipos. Abre la ficha federativa con los botones, navega hasta el equipo y pulsa **Leer** para intentar capturar actas/tablas. La caché local indica origen y fecha. Si no se puede leer, aparecen guiones/pendiente. No desactives Play Protect.

**Seguridad**: En WebView remoto no se instala interfaz JavaScript. Solo se permite navegación HTTPS en fcf.cat. No se guardan datos personales de jugadores.

**Alcance real**: el resultado automático depende de que la FCF muestre datos identificables en el HTML de la página. No es garantía de que se recuperen los tres indicadores ni el seguimiento en vivo.


## V9.1: correcciones verificadas

- Corrección de nombres Cadete/Femenino de los 27 equipos.
- Asociación estricta de actas por familia, subedad (S7-S16), división y grupo; sin asignar resultados ambiguos.
- Acepta páginas con `fcf.cat` y `www.fcf.cat` como origen.
- Validación de que el Ciutat Cooperativa participe efectivamente en un acta extraída.
- Evita guardar favoritos con identificadores inválidos.

**Fase de validación:** pasa pruebas unitarias de JavaScript; falta compilación con Android SDK real, ejecución en dispositivo y lectura con páginas FCF actuales.

- Datos iniciales incluidos en `index.html` para evitar restricciones de `fetch(file://)` dentro de Android WebView.
