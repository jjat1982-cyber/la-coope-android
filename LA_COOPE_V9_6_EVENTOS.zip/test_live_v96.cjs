'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const js=fs.readFileSync('app/src/main/assets/fcf-reader.js','utf8');
function parse(raw){const document={body:{innerText:raw},querySelectorAll:()=>[]};return JSON.parse(vm.runInNewContext(js,{document,location:new URL('https://www.fcf.cat/ca/competicio/2026-2027/primera-catalana/grup-3/resultats'),Date,URL},{timeout:900}));}
const live='RESULTATS\nJORNADA 12\nCIUDAD COOPERATIVA C.F. A\nEN DIRECTE\n09/11/2026\n18:00\n1 - 0\nASCÓ C.F. A';
const parsed=parse(live);
assert.equal(parsed.live.length,1);assert.equal(parsed.live[0].score,'1-0');assert.equal(parsed.results.length,0);
const ended=parse(live.replace('EN DIRECTE','ACTA TANCADA'));
assert.equal(ended.live.length,0);assert.equal(ended.results.length,1);
const other=parse('RESULTATS\nJORNADA 12\nSANTBOIA, F.C. A\nEN DIRECTE\n09/11/2026\n18:00\n1 - 0\nASCÓ C.F. A');
assert.equal(other.live.length,0);
console.log('PASS: solo marcadores en directo declarados por FCF y pertenecientes a LA COOPE');
