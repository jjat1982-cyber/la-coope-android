'use strict';
const fs=require('fs'), vm=require('vm'),assert=require('node:assert/strict');
const base='app/src/main/assets/';
const script=fs.readFileSync(base+'app.js','utf8');
const teams=JSON.parse(fs.readFileSync(base+'teams.json','utf8'));
const verified=JSON.parse(fs.readFileSync(base+'verified.json','utf8'));
const seen=[];
const shell={
  LA_COOPE_INLINE:{teams,verified},
  LACOOPE:{screenShown:(screen,id)=>seen.push(['screen',screen,id]),watchLive:(enabled,id)=>seen.push(['live',enabled,id]),favoriteChanged:(id)=>seen.push(['favorite',id]),refresh:()=>seen.push(['manual'])},
  addEventListener(){},scrollTo(){},open(){}
};
const display={innerHTML:''},toast={textContent:'',classList:{add(){},remove(){}}};
const nodes={view:display,toast,'install-button':{addEventListener(){},hidden:true}};
const storage=new Map();const document={getElementById:k=>nodes[k]||null,querySelectorAll:()=>[],addEventListener(){}};
const context={window:shell,document,localStorage:{getItem:k=>storage.get(k)||'',setItem:(k,v)=>storage.set(k,String(v))},navigator:{},location:{protocol:'file:'},URL,Date,console,setTimeout,clearTimeout};
vm.runInNewContext(script,context);
setTimeout(()=>{
  vm.runInNewContext("navigate('partidos')",context);
  assert.deepEqual(seen.at(-1),['screen','partidos','amateur-a']);
  vm.runInNewContext("pick('prebenjamin-s7-a')",context);
  assert.deepEqual(seen.at(-1),['screen','partidos','prebenjamin-s7-a']);
  vm.runInNewContext('changeLiveWatching()',context);
  assert.deepEqual(seen.at(-1),['live',false,'prebenjamin-s7-a']);
  assert.match(display.innerHTML,/No hay un marcador en directo verificado/);
  vm.runInNewContext("navigate('clasificacion')",context);
  assert.deepEqual(seen.at(-1),['screen','clasificacion','prebenjamin-s7-a']);
  vm.runInNewContext("navigate('inicio')",context);
  assert.deepEqual(seen.at(-1),['screen','inicio','amateur-a']);
  const java=fs.readFileSync('app/src/main/java/com/lacoope/santboi/MainActivity.java','utf8');
  assert(java.includes('onStop(){super.onStop();stoppedSinceLastResume=true;'));
  assert(!java.includes('System.currentTimeMillis()-lastRefresh>15*60*1000L'));
  assert(java.includes('private static final long LIVE_INTERVAL_MS = 120_000L;'));
  assert(java.includes('if(liveWatching&&liveVerified&&!stoppedSinceLastResume'));
  assert(java.includes('if(autoPhase>=(liveOnlyRequest?1:3))'));
  console.log('PASS: Inicio, cambios de pantalla/favorito, directo condicionado, sin recarga temporal general');
},35);
