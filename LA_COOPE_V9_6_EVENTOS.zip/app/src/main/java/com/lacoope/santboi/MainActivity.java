package com.lacoope.santboi;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONTokener;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final String COMP = "https://www.fcf.cat/ca/competicio";
    private static final String AMATEUR_RESULTS = "https://www.fcf.cat/ca/competicio/2026-2027/primera-catalana/grup-3/resultats";
    private static final String HOME = "file:///android_asset/index.html";
    private WebView homeView, fcfView, autoView;
    private LinearLayout officialLayout;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String extractor = "", autoDriver = "";
    private boolean homeReady = false, autoRunning = false;
    private int captureGeneration = 0, autoGeneration = 0, autoStep = 0, autoPhase = 0, autoAttempts = 0;
    private boolean autoPhaseTabClicked = false;
    private boolean autoTickBusy = false, autoReadBusy = false;
    private String favorite = "";
    private final ArrayList<JSONObject> tasks = new ArrayList<>();
    private JSONObject currentTask = null;
    private JSONArray teams = new JSONArray();
    private long lastRefresh = 0;
    private boolean stoppedSinceLastResume = false;
    private boolean liveWatching = false, liveVerified = false, liveOnlyRequest = false;
    private String liveTeam = "";
    private static final long LIVE_INTERVAL_MS = 120_000L;
    private final Runnable liveUpdate = ()->{
        if(liveWatching && liveVerified && !stoppedSinceLastResume && "partidos".equals(activeScreen)){
            // Un fallo de la consulta no debe prolongar indefinidamente el seguimiento.
            liveVerified=false;
            liveOnlyRequest=true;
            refreshOnScreenEntry("partidos",liveTeam);
        }
    };
    private String activeScreen = "inicio";
    private String activeTeam = "amateur-a";
    private int collectedRecords = 0;
    private String lastFailure = "";
    private String selectorNote = "";
    private TextView readStatus;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(Color.rgb(20,20,20));
        getWindow().setNavigationBarColor(Color.rgb(20,20,20));
        try {extractor = readAsset("fcf-reader.js"); autoDriver = readAsset("fcf-auto.js");teams = new JSONArray(readAsset("teams.json"));}
        catch(Exception e){extractor="";autoDriver="";}

        FrameLayout root = new FrameLayout(this);
        // Kept behind the home UI, but attached and able to render/execute the real official webpage.
        autoView = new WebView(this); configure(autoView);
        autoView.setAlpha(0.01f); autoView.getSettings().setAllowFileAccess(false);
        autoView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return r.isForMainFrame() && !isAllowed(r.getUrl());}
            @Override public void onPageFinished(WebView v,String url){if(autoRunning && isAllowed(Uri.parse(url))){int gen=autoGeneration;handler.postDelayed(()->{if(gen==autoGeneration)autoTick();},1600);}}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame()&&autoRunning)finishTask("La FCF no respondió a la consulta automática");}
        });
        root.addView(autoView,new FrameLayout.LayoutParams(-1,-1));

        homeView=new WebView(this); configure(homeView);
        homeView.addJavascriptInterface(new LocalBridge(),"LACOOPE");
        homeView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){
                if(HOME.equals(url)){
                    homeReady=true;
                    handler.postDelayed(()-> homeView.evaluateJavascript("window.LA_COOPE_syncTarget && window.LA_COOPE_syncTarget()",value->{
                        try{JSONObject j=new JSONObject(decodeString(value));favorite=j.optString("favorite","");}catch(Exception ignored){}
                        startAutomaticSync();
                    }),500);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !HOME.equals(r.getUrl().toString());}
        });
        root.addView(homeView,new FrameLayout.LayoutParams(-1,-1));

        fcfView=new WebView(this);configure(fcfView);
        fcfView.getSettings().setAllowFileAccess(false);fcfView.getSettings().setAllowContentAccess(false);
        fcfView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return r.isForMainFrame() && !isAllowed(r.getUrl());}
            @Override public void onPageFinished(WebView view,String url){
                if(isAllowed(Uri.parse(url))){
                    int id=++captureGeneration;
                    for(long delay:new long[]{1200,3000})handler.postDelayed(()->{
                        if(id==captureGeneration&&fcfView!=null&&fcfView.getUrl()!=null&&isAllowed(Uri.parse(fcfView.getUrl())))readOfficialPage(false);
                    },delay);
                }
            }
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())manualFeedback("No se pudo abrir la página oficial");}
        });
        officialLayout=new LinearLayout(this);
        officialLayout.setOrientation(LinearLayout.VERTICAL);officialLayout.setBackgroundColor(Color.WHITE);
        LinearLayout toolbar=new LinearLayout(this);
        toolbar.setPadding(8,6,8,6);toolbar.setBackgroundColor(Color.rgb(255,202,6));
        Button back=new Button(this);back.setText("← LA COOPE");back.setOnClickListener(v->returnHome());
        toolbar.addView(back,new LinearLayout.LayoutParams(0,-2,1));
        readStatus=new TextView(this);readStatus.setText("Página oficial");readStatus.setTextColor(Color.BLACK);readStatus.setTextSize(12);readStatus.setPadding(6,18,6,0);
        toolbar.addView(readStatus,new LinearLayout.LayoutParams(0,-2,1));
        Button read=new Button(this);read.setText("LEER");
        read.setOnClickListener(v->{manualFeedback("Leyendo la página oficial…");readOfficialPage(true);});
        toolbar.addView(read,new LinearLayout.LayoutParams(0,-2,1));
        officialLayout.addView(toolbar);
        officialLayout.addView(fcfView,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(officialLayout,new FrameLayout.LayoutParams(-1,-1));
        officialLayout.setVisibility(View.GONE);
        setContentView(root);
        homeView.loadUrl(HOME);
    }

    private void configure(WebView v){
        // Las cookies propias permiten conservar una elección de consentimiento
        // realizada por el usuario en la página oficial; nunca se aceptan automáticamente.
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(v,false);
        WebSettings s=v.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);v.setBackgroundColor(Color.WHITE);
    }
    private static boolean isAllowed(Uri uri){
        if(uri==null||!"https".equalsIgnoreCase(uri.getScheme()))return false;
        String h=uri.getHost();return "fcf.cat".equals(h)||"www.fcf.cat".equals(h);
    }
    private String decodeString(String raw)throws Exception{
        Object decoded=new JSONTokener(raw).nextValue();
        return decoded instanceof String?(String)decoded:raw;
    }
    private final class LocalBridge{
        @JavascriptInterface public void openOfficial(String url){handler.post(()->showOfficial(url));}
        @JavascriptInterface public void refresh(){handler.post(()->{autoGeneration++;autoRunning=false;startAutomaticSync();});}
        @JavascriptInterface public void favoriteChanged(String id){handler.post(()->{favorite=id;startAutomaticSync();});}
        @JavascriptInterface public void sync(){handler.post(()->startAutomaticSync());}
        // Se invoca cuando el usuario entra en una pantalla; sin intervalo periódico.
        @JavascriptInterface public void screenShown(String screen, String teamId){
            handler.post(()->refreshOnScreenEntry(screen, teamId));
        }
        @JavascriptInterface public void watchLive(boolean enabled, String teamId){
            handler.post(()->{
                handler.removeCallbacks(liveUpdate);
                liveWatching=enabled;liveVerified=false;
                liveTeam=team(teamId)!=null?teamId:"";
                if(liveWatching && !liveTeam.isEmpty())refreshOnScreenEntry("partidos",liveTeam);
            });
        }
    }
    private void showOfficial(String url){
        Uri uri=Uri.parse(url);
        if(!isAllowed(uri)){pushStatus("Solo se permiten páginas oficiales fcf.cat");return;}
        officialLayout.setVisibility(View.VISIBLE);readStatus.setText("Página oficial · LEER");fcfView.loadUrl(url);
    }
    private void manualFeedback(String message){
        readStatus.setText(message.length()>40?message.substring(0,38)+"…":message);
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();
    }
    private void readOfficialPage(boolean showFeedback){
        if(fcfView==null||fcfView.getUrl()==null||!isAllowed(Uri.parse(fcfView.getUrl()))||extractor.isEmpty()){
            if(showFeedback)manualFeedback("La página oficial todavía no se ha cargado");return;
        }
        fcfView.evaluateJavascript(extractor,value->{
            try{
                JSONObject obj=parsePayload(value);
                if(obj==null){if(showFeedback)manualFeedback("No se ha podido interpretar la página");return;}
                if(obj.has("error")){
                    if(showFeedback)manualFeedback("FCF: "+obj.optString("error"));
                    pushStatus("FCF: "+obj.optString("error"));return;
                }
                deliver(obj);
                int count=obj.optJSONArray("results")==null?0:obj.optJSONArray("results").length();
                count+=obj.optJSONArray("fixtures")==null?0:obj.optJSONArray("fixtures").length();
                count+=obj.optJSONArray("standings")==null?0:obj.optJSONArray("standings").length();
                if(showFeedback)manualFeedback(count>0?"Detectados "+count+" registros. Volver a LA COOPE para verlos.":"No se encontraron datos asignables en esta página");
            }catch(Exception e){if(showFeedback)manualFeedback("Error al interpretar los resultados de FCF");}
        });
    }
    private JSONObject parsePayload(String value){
        try{
            JSONObject obj=new JSONObject(decodeString(value));
            if(!"fcf.cat".equals(obj.optString("source")))return null;
            if(!isAllowed(Uri.parse(obj.optString("url"))))return null;
            return obj;
        }catch(Exception e){return null;}
    }
    private void deliver(JSONObject obj){
        if(homeReady)homeView.evaluateJavascript("window.LA_COOPE_receive("+JSONObject.quote(obj.toString())+");",null);
    }
    private void pushStatus(String message){
        if(homeReady&&homeView!=null)homeView.evaluateJavascript("window.LA_COOPE_status("+JSONObject.quote(message)+");",null);
    }
    private JSONObject team(String id){
        for(int i=0;i<teams.length();i++){JSONObject a=teams.optJSONObject(i);if(a!=null&&id.equals(a.optString("id")))return a;}
        return null;
    }
    private boolean taskQueued(String id){
        if(id == null || id.isEmpty())return false;
        for(int i=autoStep;i<tasks.size();i++)if(id.equals(tasks.get(i).optString("id")))return true;
        return false;
    }
    private void addTaskIfMissing(JSONObject task){
        if(task!=null&&!taskQueued(task.optString("id")))tasks.add(task);
    }
    private void beginNewSync(){
        autoGeneration++;autoRunning=true;autoStep=0;collectedRecords=0;
        lastFailure="";lastRefresh=System.currentTimeMillis();
        pushStatus("Consultando la información oficial…");
        beginTask();
    }
    private void startAutomaticSync(){
        if(!homeReady||autoView==null||extractor.isEmpty()||autoDriver.isEmpty()){
            pushStatus("No se pudo preparar la actualización automática");return;
        }
        // Al abrir Inicio: Amateur A y favorito; no interrumpir otra consulta activa.
        if(autoRunning){
            addTaskIfMissing(team("amateur-a"));
            if(!"amateur-a".equals(favorite))addTaskIfMissing(team(favorite));
            return;
        }
        tasks.clear();
        addTaskIfMissing(team("amateur-a"));
        if(!"amateur-a".equals(favorite))addTaskIfMissing(team(favorite));
        beginNewSync();
    }
    private void refreshOnScreenEntry(String screen, String teamId){
        if(!homeReady)return;
        if(!"inicio".equals(screen)&&!"partidos".equals(screen)&&!"resultados".equals(screen)
            &&!"clasificacion".equals(screen)&&!"equipos".equals(screen))return;
        activeScreen=screen;
        if(!"partidos".equals(screen)){
            liveWatching=false;liveVerified=false;handler.removeCallbacks(liveUpdate);
        }
        if(team(teamId)!=null)activeTeam=teamId;
        if(liveWatching && !activeTeam.equals(liveTeam)){
            liveWatching=false;liveVerified=false;handler.removeCallbacks(liveUpdate);
        }
        if("equipos".equals(screen))return; // Lista estática: no es necesario solicitar la FCF.
        if(!"partidos".equals(screen))liveOnlyRequest=false;
        if("inicio".equals(screen)){startAutomaticSync();return;}
        JSONObject target=team(activeTeam);
        if(target==null)return;
        if(autoRunning){addTaskIfMissing(target);return;}
        tasks.clear();addTaskIfMissing(target);beginNewSync();
    }
    private void beginTask(){
        if(!autoRunning)return;
        if(autoStep>=tasks.size()){
            autoRunning=false;
            liveOnlyRequest=false;
            handler.removeCallbacks(liveUpdate);
            if(liveWatching&&liveVerified&&!stoppedSinceLastResume&&"partidos".equals(activeScreen))
                handler.postDelayed(liveUpdate,LIVE_INTERVAL_MS);
            String now=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date());
            pushStatus(collectedRecords>0?("FCF: "+collectedRecords+" registros reconocidos · "+now):( "Sin datos nuevos ("+now+"). "+(lastFailure.isEmpty()?"La FCF no ha ofrecido registros verificables.":lastFailure)+" · Puedes pulsar Actualizar"));
            return;
        }
        currentTask=tasks.get(autoStep);autoAttempts=0;autoPhase=0;autoPhaseTabClicked=false;autoTickBusy=false;autoReadBusy=false;
        pushStatus("Actualizando "+currentTask.optString("name")+" desde la FCF…");
        // La dirección directa fue obtenida por el usuario en Chrome: evita los selectores dinámicos rotos.
        autoView.loadUrl(isDirectAmateur()?AMATEUR_RESULTS:COMP);
    }
    private boolean isDirectAmateur(){
        return currentTask!=null && "amateur-a".equals(currentTask.optString("id"));
    }
    private void finishTask(String reason){
        if(!autoRunning)return;
        int current=autoGeneration;
        if(reason.startsWith("FCF no ha permitido")||reason.startsWith("FCF: "))lastFailure=reason;
        pushStatus(reason);
        autoStep++;
        handler.postDelayed(()->{if(autoRunning&&current==autoGeneration)beginTask();},450);
    }
    private void autoTick(){
        if(!autoRunning||autoView==null||currentTask==null||autoTickBusy||autoReadBusy)return;
        autoTickBusy=true;
        int gen=autoGeneration;
        if(++autoAttempts>22){autoTickBusy=false;finishTask("FCF no ha permitido seleccionar "+currentTask.optString("name")+" ("+selectorNote+")");return;}
        JSONObject target=new JSONObject();
        try{target.put("division",currentTask.optString("division"));target.put("group",currentTask.optString("group"));
            String cat=currentTask.optString("category").toLowerCase(java.util.Locale.ROOT);
            target.put("discipline",(cat.contains("prebenjam")||cat.contains("benjam")||cat.contains("alev"))?"futbol 7":"futbol 11");}
        catch(Exception ignored){}
        // Para Amateur A la URL /primera-catalana/grup-3/resultats ya fija categoría y grupo;
        // no se debe intentar seleccionar manualmente cuatro desplegables.
        String driver = isDirectAmateur()
           ? "JSON.stringify({state:'ready',reason:'Primera Catalana grupo 3 por URL oficial directa'})"
           : "window.__COOPE_TARGET__="+target.toString()+";"+autoDriver;
        autoView.evaluateJavascript(driver,value->{
            autoTickBusy=false;
            if(!autoRunning||gen!=autoGeneration)return;
            try{
                JSONObject answer=new JSONObject(decodeString(value));
                String state=answer.optString("state");selectorNote=answer.optString("reason","");
                if("ready".equals(state)){
                    // Results is the default active tab on the official group page.
                    if(autoPhase==0){readAutomaticPage();return;}
                    if(!autoPhaseTabClicked){
                        autoPhaseTabClicked=true;
                        String label=autoPhase==1?"CLASSIFICACI":"CALENDARI";
                        String js="(function(){const q="+JSONObject.quote(label)+";const norm=s=>String(s||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toUpperCase();const buttons=[...document.querySelectorAll('button,a,[role=tab]')];const b=buttons.find(x=>norm(x.innerText||'').includes(norm(q)));if(b){b.click();return 'clicked';}return 'missing';})()";
                        autoView.evaluateJavascript(js,clicked->{
                            if(gen!=autoGeneration||!autoRunning)return;
                            String status="";try{status=decodeString(clicked);}catch(Exception ignored){}
                            if("clicked".equals(status))handler.postDelayed(()->{if(gen==autoGeneration)readAutomaticPage();},1800);
                            else{autoPhase++;autoPhaseTabClicked=false;scheduleAutoTick(gen,450);}
                        });
                    }else scheduleAutoTick(gen,1100);
                }else if("blocked".equals(state))finishTask("FCF no ha permitido seleccionar "+currentTask.optString("name")+": "+answer.optString("reason","selector no reconocido"));
                else if("error".equals(state))finishTask("FCF: "+answer.optString("reason","Error de consulta"));
                else {
                    if(autoAttempts==3 || autoAttempts==8)pushStatus("FCF · "+currentTask.optString("name")+": "+selectorNote);
                    scheduleAutoTick(gen,1200);
                }
            }catch(Exception e){scheduleAutoTick(gen,1200);}
        });
    }
    private void readAutomaticPage(){
        if(!autoRunning||currentTask==null||autoView==null||autoReadBusy)return;
        autoReadBusy=true;
        int gen=autoGeneration;
        autoView.evaluateJavascript(extractor,value->{
            autoReadBusy=false;
            if(!autoRunning||gen!=autoGeneration)return;
            JSONObject p=parsePayload(value);
            if(p!=null&&!p.has("error")){
                // The category/group were confirmed by the official site's own selectors.
                if(p.optString("category").isEmpty()||p.optString("group").isEmpty()){
                    try{
                        if(p.optString("category").isEmpty())p.put("category",currentTask.optString("division"));
                        if(p.optString("group").isEmpty())p.put("group",currentTask.optString("group"));
                    }catch(Exception ignored){}
                }
                if(liveWatching && "partidos".equals(activeScreen)
                    && currentTask.optString("id").equals(liveTeam) && autoPhase==0){
                    JSONArray live=p.optJSONArray("live");
                    liveVerified=live!=null && live.length()>0;
                }
                int n=(p.optJSONArray("results")==null?0:p.optJSONArray("results").length())
                     +(p.optJSONArray("fixtures")==null?0:p.optJSONArray("fixtures").length())
                     +(p.optJSONArray("standings")==null?0:p.optJSONArray("standings").length());
                collectedRecords+=n;
                deliver(p);
            }
            autoPhase++;autoPhaseTabClicked=false;
            if(autoPhase>=(liveOnlyRequest?1:3)){finishTask("FCF consultada para "+currentTask.optString("name")+". Comprobando datos…");}
            else scheduleAutoTick(gen,700);
        });
    }
    private void scheduleAutoTick(int gen,long delay){handler.postDelayed(()->{if(gen==autoGeneration&&autoRunning)autoTick();},delay);}
    private String readAsset(String name)throws Exception{
        try(InputStream in=getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
    private void returnHome(){if(fcfView!=null)readOfficialPage(false);officialLayout.setVisibility(View.GONE);}
    @Override public void onBackPressed(){
        if(officialLayout.getVisibility()==View.VISIBLE){if(fcfView.canGoBack())fcfView.goBack();else returnHome();}
        else super.onBackPressed();
    }
    // Una consulta al volver del segundo plano. No hay tareas periódicas para datos normales.
    @Override protected void onStop(){super.onStop();stoppedSinceLastResume=true;handler.removeCallbacks(liveUpdate);}
    @Override public void onResume(){
        super.onResume();
        if(stoppedSinceLastResume){
            stoppedSinceLastResume=false;
            handler.post(()->{
                if(!homeReady)return;
                if("inicio".equals(activeScreen))startAutomaticSync();
                else refreshOnScreenEntry(activeScreen,activeTeam);
            });
        }
    }
    @Override protected void onDestroy(){captureGeneration++;autoGeneration++;autoRunning=false;handler.removeCallbacks(liveUpdate);
        if(autoView!=null){autoView.destroy();autoView=null;}
        if(fcfView!=null){fcfView.destroy();fcfView=null;}
        if(homeView!=null){homeView.destroy();homeView=null;}
        super.onDestroy();
    }
}
