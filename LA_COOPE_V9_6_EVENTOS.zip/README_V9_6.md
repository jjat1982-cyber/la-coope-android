# LA COOPE V9.6 — Actualización por eventos

Aplicación Android personal del CF Ciudad Cooperativa, sin publicación en Google Play.

## Comportamiento

- Al abrir la app: se muestran inmediatamente los últimos datos verificables guardados, después se consulta automáticamente el Amateur A y el favorito.
- Al volver desde segundo plano: nueva consulta al equipo visible sin intervalo periódico.
- Al entrar en Inicio, Calendario/Partidos, Resultados o Clasificación: solicita datos de los equipos correspondientes. Cambiar de equipo en las pantallas también dispara una nueva lectura.
- Botón «Actualizar»: reinicia una consulta manual incluso si hay otra en curso.
- En Partidos, al entrar se comprueba si hay un directo oficial. **Solo si el lector reconoce un partido marcado expresamente «EN DIRECTE» con marcador y el club correcto** se vuelve a consultar cada 120 segundos; se detiene al salir de la pantalla, al poner la app en segundo plano o cuando ya no se verifica el directo.
- Los marcadores en directo almacenados se dejan de mostrar como actuales después de 5 minutos sin verificación.
- No hay consultas por intervalo para resultados finalizados, próximos encuentros, clasificación o equipos.
- Las cookies propias del sitio se pueden conservar después de que el usuario dé el consentimiento, sin aceptación automática de las opcionales.

## Límites conocidos

- La FCF publica información en su web, pero sus formatos cambian y nuestro lector aún **no ha sido validado en vivo contra todas sus páginas**, por lo que no se garantiza que las tarjetas se rellenen automáticamente.
- El Amateur A tiene la URL oficial directa `https://www.fcf.cat/ca/competicio/2026-2027/primera-catalana/grup-3/resultats`; el resto de los equipos necesitarán URLs de categoría y grupo verificadas. A día de hoy pueden seguir usando el selector que ya ha presentado fallos.
- La detección y actualización de marcadores en directo es experimental, solo funciona si la FCF muestra explícitamente los datos reconocibles. No es una retransmisión de vídeo.
- La versión entregada es código fuente para compilar. No hay APK V9.6 compilado ni probado en móvil real en esta entrega.

## Compilar desde GitHub

Subir el archivo `LA_COOPE_V9_6_EVENTOS.zip` a `jjat1982-cyber/la-coope-android` y sustituir el workflow `.github/workflows/compilar-apk.yml` con `LA_COOPE_V9_6_compilar-apk.yml`. GitHub Actions generará `app-debug.apk` como artifact si la compilación termina correctamente.

Las pruebas de Node.js incluidas cubren el lector, la asignación de equipos, el filtrado de directos, los favoritos y los eventos de actualización. No sustituyen una prueba física del WebView.
