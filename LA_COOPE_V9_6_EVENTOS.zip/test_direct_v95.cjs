'use strict';
const fs=require('fs');const vm=require('vm');const assert=require('node:assert/strict');
const reader=fs.readFileSync('app/src/main/assets/fcf-reader.js','utf8');
const base='https://www.fcf.cat/ca/competicio/2026-2027/primera-catalana/grup-3/';
function parse(text,path='resultats'){
  const document={body:{innerText:text},querySelectorAll:()=>[]};
  return JSON.parse(vm.runInNewContext(reader,{document,location:new URL(base+path),URL,Date,console},{timeout:800}));
}
const page=`RESULTATS\nJORNADA 8\nSANTBOIA, F.C. A\nACTA TANCADA\n07/11/2026\n16:00\n4 - 0\nVILA-SECA C.F. A\nCIUDAD COOPERATIVA, C.F. A\nACTA TANCADA\n08/11/2026\n12:00\n2 - 1\nSITGES, U.E. A`;
const r=parse(page);
assert.equal(r.category,'Primera Catalana');assert.equal(r.group,'3');
assert.equal(r.results.length,1,'El lector debe ignorar otros partidos del grupo');
assert.equal(r.results[0].score,'2-1');
const c=parse('CLASSIFICACIÓ\nEncara no hi ha dades','classificacio');
assert.equal(c.category,'Primera Catalana');assert.equal(c.group,'3');
const unknown=parse('JORNADA\nAltres partits','resultats');
assert.equal(unknown.results.length,0,'No se inventan marcadores');
const source=fs.readFileSync('app/src/main/java/com/lacoope/santboi/MainActivity.java','utf8');
assert(source.includes('autoView.loadUrl(isDirectAmateur()?AMATEUR_RESULTS:COMP)'));
assert(source.includes('grup-3/resultats'));
console.log('OK: URL directa /group-3, clasificación, exclusión de clubes ajenos y activación Android');
