# LA COOPE V9.5 — Acceso directo al Amateur A (experimental)

La URL facilitada por el usuario desde Chrome es:

https://www.fcf.cat/ca/competicio/2026-2027/primera-catalana/grup-3/resultats

- La actualización al abrir la app navega a esa dirección directamente para Amateur A, sin seleccionar Temporada/Disciplina/Competición/Grupo.
- El lector obtiene categoría y grupo de la URL y solo intenta mostrar los datos de CIUDAD/CIUTAT COOPERATIVA que sean identificables y fechados.
- Para clasificación/calendario, intenta seguir las pestañas/enlaces de la página oficial. No se han verificado sus enlaces concretos en este entorno.
- Para el equipo favorito (otras categorías), persiste el procedimiento experimental por selectores hasta disponer de su URL directa.
- No se inventan resultados ni se eluden restricciones de acceso. La consulta real debe probarse en Android.
- Proyecto Android con versionCode 19; compilar con el workflow `compilar-apk.yml` de GitHub Actions usando el archivo ZIP entregado.

**Nota**: solo la compilación Android en GitHub y la prueba en Samsung validarán esta modificación; no es una sincronización completa confirmada.

---
# LA COOPE V9.4 (experimental)

**Objetivo:** selección segura de temporada, modalidad, competición y grupo en las páginas públicas de fcf.cat.

- Elimina los clics a ciegas sobre controles por orden de aparición.
- Detecta los 4 campos por sus etiquetas, atributos accesibles, contenido de opciones o selección visible.
- Comprueba cada valor seleccionado antes de leer partidos.
- Si falta el campo o las opciones no aparecen, detiene el intento y muestra qué selector ha fallado.
- Mantiene la actualización al abrir, el botón de reintento y los favoritos.
- No usa servidores deportivos de terceros ni evade restricciones.

**Limitación:** la estructura real de los componentes personalizados de la FCF no es inspeccionable desde este entorno. La v9.4 ha superado pruebas locales simuladas con `<select>`, menús personalizados y controles ausentes, pero la selección automática **aún debe verificarse en un Samsung contra la web real**. No se afirma que los resultados estén sincronizados hasta esa prueba.

**GitHub:** subir `LA_COOPE_V9_4_GitHub_NUEVO.zip` a la raíz de tu repositorio y cambiar el `unzip -o` del workflow por el nuevo nombre, luego compilar. Es un proyecto Android, NO un APK ya compilado.

# LA COOPE V9.3 — lectura automática experimental de datos FCF

Proyecto Android (Java, Android SDK 36, Gradle 8.13, JDK 17) para uso personal, sin Play Store.

## Cambios respecto a la V9.2

- La aplicación intenta leer los datos oficiales **al abrirse**, sin pulsar «LEER».
- Consulta automáticamente **Amateur A** y **el equipo favorito seleccionado**, en ese orden.
- **Actualizar** repite la consulta; no abre la FCF manualmente.
- La consulta automática navega mediante un WebView secundario dentro de `fcf.cat`, seleccionando temporada, disciplina (Fútbol 11/7), competición y grupo mediante los controles públicos.
- `fcf-reader.js` reconoce **actas**, **tarjetas de resultados cerrados**, calendarios y tablas cuando su marcado permite identificar categoría, grupo y club.
- El botón manual **LEER** ahora muestra el resultado o un error concreto mediante un aviso Android visible.
- Se conserva una caché local de lo último que pudo verificarse sin inventar marcadores.

## Limitaciones importantes

- **La automatización del selector FCF NO ha podido probarse contra la web real ni en un Samsung físico** en este entorno. Puede fallar si el selector no emplea controles HTML reconocibles o cambia su estructura.
- Las pruebas pasan con páginas de ejemplo que simulan el DOM y las tarjetas vistas en capturas, no prueban la sincronización real de los 27 equipos.
- No se ha encontrado ni utilizado una API privada, ni un proveedor de resultados, ni un proxy externo: la propia WebView consulta `https://www.fcf.cat`.
- «En directo» solo mostrará información publicada por la FCF; no se simula la retransmisión ni se garantizan marcadores minuto a minuto.
- La portada puede mostrar «Sin datos nuevos» si la FCF no facilita los datos de forma interpretable.

## Compilación con GitHub Actions

Subir el ZIP **sin descomprimir** al repositorio como `LA_COOPE_V9_3_GitHub_NUEVO.zip` y editar `.github/workflows/compilar-apk.yml` para que el paso de extracción ejecute:

```
run: unzip -o LA_COOPE_V9_3_GitHub_NUEVO.zip
```

El resto del flujo de compilación que ya funcionó para la V9.2 puede mantenerse. Se recomienda cambiar el nombre del artefacto a `LA_COOPE_V9_3_APK`.

Al guardar el commit en `main` se generará un nuevo APK de depuración si la compilación pasa. La versión 9.3 aumenta `versionCode` a 17. Una firma de depuración distinta puede obligar a desinstalar la anterior y se perderán los favoritos guardados.

## Pruebas locales

```
node test_v93.cjs
node test_v92.cjs
python validate_java.py
```

`validate_java.py` usa clases simuladas para comprobar **sintaxis Java**, no equivale a la compilación Android con SDK. El workflow de GitHub realiza la compilación real.
